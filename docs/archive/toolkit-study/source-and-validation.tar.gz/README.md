# Better Pets: toolkit comparison

Two matched desktop-pet prototypes compare Godot with Qt Quick. Both render the
same authored 12-part character, run the same procedural motion, and expose the
same timed scenarios. This is a toolkit experiment, not a finished companion.

Current status: both release implementations and motion tests work. A native
macOS screening run completed 24/24 candidate trials outside the execution
sandbox. Qt used less memory and lower mean application CPU in all four scenarios,
but interaction during some trials and rendering-cadence differences prevent a
controlled efficiency conclusion. Battery impact remains unverified. Read the
[results and next comparison steps](docs/results/2026-10-08-comparison.md).

The initial host is Apple Silicon macOS. The rendering/behavior code is portable;
Windows and Linux desktop integration and performance have not been validated.

## Setup

Requires Python 3.12+, `uv`, CMake, Apple's command-line C++ tools, curl, and unzip.
The local bootstrap downloads Godot 4.7.2 with matching release templates and
Qt 6.10.3. Downloads, tools, virtual environment, and build outputs remain here.
Allow several GB of temporary space for the complete Godot template archive.

```sh
rtk uv run --cache-dir .cache/uv python tools/bootstrap.py
rtk proxy .venv/bin/python -m unittest discover -s tests -v
rtk proxy .venv/bin/python tools/build_qt.py --qt-prefix .deps/qt/6.10.3/macos
rtk proxy .venv/bin/python tools/build_godot.py --renderer all
rtk proxy .venv/bin/python tools/configure.py
```

Godot download archives are checked against the release's published SHA512
manifest. Qt archives are obtained through the pinned aqt installer. Toolchain
provenance is recorded in `.deps/toolchains.json`. The source uses no paid service
or model inference.

See the engine build scripts' `--help` for platform paths and export options.
Run applications from this workspace with `--assets` pointing to the shared
directory. The common application arguments are:

```text
--scenario static|idle-motion|walk-fixed|walk-desktop|hidden|mixed-active|mixed-rest
--duration SECONDS --warmup SECONDS --output TELEMETRY_JSON --assets SHARED_DIR
--ready-file READINESS_JSON
--dump-poses POSE_JSON
--screenshot IMAGE_PNG
```

Godot receives application arguments after `--`. Duration includes warmup; the
scenario restarts at tick zero after warmup. Pose dumps and screenshots are for
untimed validation. Apps exit automatically when their requested duration ends.
The optional readiness file is published after setup, immediately before runtime
clocks start, and contains `ready: true` with the process PID. The collector uses
it to separate startup from measurement; file-observation timing remains bounded
and approximate rather than an exact shared-clock synchronization.

## What the benchmark measures

| Scenario | Behavior |
|---|---|
| static | Visible, frozen pose |
| idle-motion | Continuous breathing, gaze and tail motion |
| walk-fixed | Gait and root motion inside a stationary window |
| walk-desktop | The same motion applied to desktop-window position |
| hidden | Hidden surface, suspended application animation |
| mixed-active | 45 seconds animated idle, 15 seconds desktop walking |
| mixed-rest | 40 seconds frozen, 15 walking, 5 animated idle |

The primary proposed battery target is less than 5% runtime loss with
`mixed-active` and a declared foreground workload. It is **unverified** until
controlled whole-system battery trials establish it. CPU, memory, and component
power estimates cannot prove that target.

The [collector guide](bench/README.md) documents configuration and output. Its
configuration uses command argument arrays, never shell strings. Run one toolkit
at a time; randomized paired blocks have no-pet controls before and after.

```sh
rtk proxy .venv/bin/python -m bench.run \
  --config bench/config.local.json --output results/comparison \
  --warmup 30 --duration 120 --repeats 3
```

Raw samples, errors, engine telemetry, run metadata, and summary reports are kept
together. Missing permissions produce explicit missing metrics. Early process
exit and malformed telemetry invalidate a run. Root-only process measurements
remain useful diagnostics, but do not represent the entire process tree or
desktop compositor.

Do not interpret a headless/offscreen renderer as a desktop performance result.
Verify alpha, input passthrough, focus behavior, scale, renderer and frame cadence
before choosing a toolkit. Engine draw/submission callbacks do not prove physical
display presentation. Never record screenshots/video during energy timing.

## Shared motion contract

[shared/CONTRACT.md](shared/CONTRACT.md) specifies the rig, coordinate system,
fixed-step equations, pause/resume semantics, and JSON pose format. The Python
reference produces golden poses; both engines must match within 0.0001 units.

```sh
rtk proxy .venv/bin/python tools/verify.py \
  --actual results/qt-poses.json --actual results/godot-poses.json \
  --output results/pose-verification.json
```

The atlas is simple authored geometry generated deterministically with Pillow;
it is a workload fixture, not the final character design. Its preview is
[shared/preview.png](shared/preview.png).

## Design and progress

- [Approved comparison design](docs/superpowers/specs/2026-10-08-godot-qt-comparison-design.md)
- [Implementation plan](docs/superpowers/plans/2026-10-08-godot-qt-comparison.md)
- [Implementation ledger](docs/superpowers/plans/implementation-progress.md)

Godot is MIT licensed; Qt has module-dependent open-source/commercial licensing.
The local dependency distributions retain their own license notices. Distribution
and production packaging are outside this experiment.
