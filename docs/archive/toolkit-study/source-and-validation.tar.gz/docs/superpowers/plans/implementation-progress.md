# Implementation ledger — 2026-10-08-godot-qt-comparison

- Spec approved; user explicitly requested implementation and extensive subagent use.
- Ruling: proceed from the approved design to implementation without another plan approval — explicit user direction authorizes this step — cost if wrong: reversible implementation rework.
- Ruling: disjoint engine/collector work may proceed concurrently after the shared contract is frozen — user requested effective subagent use — cost if wrong: integration rework, controlled by contract tests.
- Initial dependency network HEAD succeeded. Toolkits will be kept inside the project.
- Git initialization denied by filesystem sandbox; files remain in the approved workspace, no commits claimed.
- Godot 4.7.2 editor/templates SHA512 verified; Qt6.10.3 qtbase/qtdeclarative installed locally. Bootstrap runs and prints correct versions.
- Shared reference and artwork complete. The reviewed input-polygon defect is fixed and covered by transformed alpha-pixel containment tests.
- Qt Release builds; final coordinator CTest passes 2/2 (golden poses and six CLI lifecycle cases). The untimed offscreen screenshot was inspected. Native GUI fails with no screens in the sandbox.
- Collector review fixes complete: requested-duration coverage, process-group cleanup, readiness synchronization with bounded observation uncertainty, strict engine telemetry checks, and validation-only report classification.
- Final coordinator Python suite passes 35/35 using `.venv/bin/python`: 12 fixture, 19 collector/report, and four pose-verifier tests.
- Godot Mobile and Compatibility release apps built. Final coordinator CLI suites pass 8/8 for each release, including process suspension across deadlines and warmup. Both native launches abort before application readiness.
- Independent cross-engine verification passes all 44 golden poses for Qt and both Godot exports within 0.0001 tolerance.
- Final end-to-end validation pipeline: 6/6 candidate runs operationally valid across static, idle-motion and hidden. Reports prominently classify headless/offscreen results as validation diagnostics, not desktop comparisons. Evidence: `results/integration/validation-final/`.
- Native smoke correctly records 0/2 valid candidates, retains startup failures and selects no winner. Evidence: `results/integration/native-smoke/`.
- Fresh engine and support re-reviews report no remaining must-fix findings. Final narrow support review confirms null-backend aliases and validation-only labeling.
- Power telemetry: powermetrics requires superuser; Instruments cache creation sandbox-denied; battery target remains unverified.
- Implementation and available software validation are complete. Native visual/interaction equivalence, graphical resource screening, cross-platform validation and controlled battery trials remain unverified. The result report and README provide the normal-Terminal reproduction commands.
