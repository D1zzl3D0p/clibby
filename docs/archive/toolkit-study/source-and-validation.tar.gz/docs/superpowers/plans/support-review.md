# Shared fixtures and benchmark tooling review

Review date: 2026-10-08. Scope: `shared/`, `tools/fixtures.py`,
`tools/bootstrap.py`, `tools/verify.py`, `bench/`, and their Python tests.
Reviewed against the approved design, implementation plan, fixture report, and
collector report. Engine implementations were outside this review. No source
changes were made. Line references refer to the reviewed revision.

**Verdict: changes required before interpreting comparison measurements.**
The deterministic reference equations, frozen-phase handling, one-core CPU
normalization, whole-block resource bootstrap, explicit unavailable energy
metrics, and refusal to select an energy winner are sound. The issues below can
invalidate the resource screening or desktop acceptance despite the passing
tests.

## Must fix

1. **P1 — Measurement coverage can accept an early exit as a complete run.**
   `bench/metrics.py:193-200` tests when an exit was observed, rather than whether
   the process survived the required measurement interval. `_aggregate` at
   lines 131-143 divides by the collected intervals rather than the declared
   measurement duration, concealing the unsampled tail. Reproduced with a real
   Python child sleeping 0.2 seconds, `duration=0.3`, `interval=0.15`: returned
   `valid=True`, no invalid reasons, and `coverage_fraction=1.0`, with only
   0.1541 seconds of measurement samples. Normalize coverage to the required
   measurement window and require evidence of completed duration; retain the
   missing tail as missing. Add a regression in which the child exits between
   the penultimate and final sample deadlines.

2. **P1 — Collector and engines do not share a measurement origin.**
   `bench/metrics.py:234-237` starts timing before `Popen`, and lines 183-184
   derive warmup/end from that timestamp. `bench/run.py:100-102` only forwards
   duration/warmup values. As acknowledged in the collector report, engines
   begin their clocks after application startup. Consequently collection
   includes a startup-dependent portion of engine warmup and excludes the
   corresponding tail of the intended workload. Mixed-cycle phase zero and
   complete-cycle claims are incorrect, especially if initialization exceeds
   warmup. Establish a bounded ready/start handshake with a shared monotonic
   start/deadline, or another measured synchronization protocol. A ready file
   alone is insufficient unless its timing semantics align both clocks. Test
   deliberately different startup delays and verify identical measured phase
   boundaries, full cycles, and bounded startup failure.

3. **P1 — Descendants survive successful or early root-process exit.**
   `bench/metrics.py:238-240` invokes process-group cleanup only while the root
   is still running. A child that outlives its root remains active during later
   baselines/candidates, violating the sequential protocol. Reproduced with a
   root spawning a five-second sleeper then exiting after 0.08 seconds: the
   collector returned exit code 0 / `early_exit`, and the descendant remained
   alive. The reviewer explicitly killed that test process group afterward.
   Clean the owned process group on every completion path, including roots
   that already exited, and record leftover descendants as a failure when
   observable. Cover clean and nonzero root exits with lingering descendants.

4. **P1 — The fixed hit polygon excludes visible ears and feet.**
   `shared/rig.json:7` bounds the polygon vertically to `[68,183]`. Applying
   the reference static hierarchy to atlas pixels with alpha >= 128 gives
   ear tips at y=55.8, rear paws at y=193.5, and front paws at y=189.5.
   Thus substantial opaque parts lie outside the advertised conservative
   silhouette even at tick zero. Input misses these areas; adapters using a
   native window shape can also clip them. Enlarge the polygon to contain all
   allowed animated poses, preserving transparent margins for passthrough.
   Add a transformed-alpha containment regression across motion extrema and
   specify that the stored coordinates are already surface coordinates, with
   only walk-fixed root displacement added by the adapter.

5. **P2 — Report comparisons include explicitly incomplete metrics.**
   `bench/report.py:11-12,35-46` reads any non-null metric without checking its
   coverage. A run may correctly be marked `metric_scope=root_only` because
   tree sampling was available for only a small fraction, yet its partial tree
   CPU/RSS is averaged and placed in paired deltas/intervals as a valid tree
   observation. Apply the declared coverage threshold per metric before
   computing means or paired differences, preserve exclusion reasons, and
   expose coverage/counts in the report. Test a valid root run with one short
   successful tree interval and otherwise unavailable tree sampling.

6. **P2 — Engine telemetry validation accepts missing workload evidence.**
   `bench/run.py:109-114` accepts `{"scenario":"static"}` as a valid engine
   summary. It does not check required counters, finite durations, the actual
   warmup/measurement boundaries, or backend/version metadata. This permits
   a runnable but incorrectly configured candidate to enter the valid resource
   summaries. Define the minimum engine-summary schema and validate required
   finite fields and requested duration/warmup/scenario against it. Keep
   unavailable optional capabilities explicit. Test minimal/missing telemetry,
   duration mismatch, and nonfinite values (Python's JSON parser accepts NaN,
   which otherwise causes a later `allow_nan=False` write to abort the suite).

## Additional completeness notes

- `tools/fixtures.py:validate_rig` does not validate `hit_polygon` or require the
  named parts used by `MotionState.pose`. Renaming a required leaf can pass
  validation and fail later during pose evaluation. Strengthen frozen-contract
  validation while adding silhouette tests.
- `tools/bootstrap.py` verifies and retains Godot's checksums, but the Qt
  manifest records only a repository root, version, installer, and archive
  categories. Preserve exact archive URLs/checksums or the installer download
  manifest to meet the plan's dependency provenance requirement.
- The bootstrap confidence intervals are resource-screening diagnostics only;
  withholding battery acceptance is correct. No energy/battery statistical
  calculation currently warrants an energy conclusion.

## Validation performed

Read all scoped implementation and test files. Did not rerun the already passing
25-test suite; instead executed the two targeted real-process reproductions
above and calculated static transformed alpha bounds directly from the authored
atlas. No engine screenshot, functional, or performance equivalence claim was
made by this review.
