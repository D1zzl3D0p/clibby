# Shared fixtures and benchmark tooling re-review

Reviewed 2026-10-08 against the findings in `support-review.md`. Scope was the
changed collector, reporting, fixture validation/containment tests, dependency
provenance, and associated documentation. Engine implementations and native
desktop acceptance were outside this review.

**Verdict: no remaining blocking findings for the current provisional tooling
deliverable.** Five original must-fix findings are addressed; synchronization is
mitigated and honestly restricted to approximate resource diagnostics. This is
not approval of an exact mixed-workload comparison or a performance conclusion.

| Original finding | Status | Evidence |
|---|---|---|
| 1. Early exit accepted with false full coverage | Addressed | Dedicated exit-wait thread detects termination independently of sampling; aggregation uses requested duration and preserves missing tails. The original 0.2/0.3-second reproduction is now a regression requiring invalidity and incomplete coverage. |
| 2. Process-launch/engine-clock mismatch | Mitigated; exact equivalence remains unverified | Collector waits for an atomic matching-PID marker with bounded startup timeout. Startup-delay and missing-readiness regressions cover the new behavior. Actual observation brackets are retained, `exact_phase_alignment` is false, and complete mixed cycles are described as requested rather than proven. |
| 3. Descendants survive root exit | Addressed on the target POSIX platform | Owned process-group cleanup executes after every root completion, including successful and nonzero exits. Observable lingering groups invalidate runs. Regressions cover both exit codes and timeout cleanup. |
| 4. Hit polygon excludes ears/paws | Addressed | Enlarged polygon includes the previous failing static bounds. The regression transforms all nonzero-alpha pixel centers through the hierarchy at golden cases and sampled motion extrema. Contract explicitly identifies absolute surface coordinates and the single walk-fixed displacement. |
| 5. Incomplete metrics enter means/paired deltas | Addressed | Report extraction independently requires finite values and at least 90% coverage for each metric. Exclusion reasons/counts and coverage are retained. Regression verifies that incomplete tree metrics are excluded while complete root metrics remain usable. |
| 6. Missing engine evidence accepted | Addressed | Minimum telemetry schema checks metadata, requested and actual durations, counters, event semantics, errors, and recursively nonfinite values. Tests reject missing/mismatched evidence and verify that NaN output invalidates its run without aborting subsequent candidates. |

The two additional completeness notes are also addressed: the rig validator now
requires the frozen part names and validates polygon geometry; Qt provenance
records exact archive URLs and published SHA256 values in
`tools/dependencies.json`, which bootstrap retains in its manifest. Those Qt
values document expected upstream archives; this review did not independently
re-hash an installed Qt tree or download archives.

The readiness observation bracket measures polling uncertainty around marker
publication. It does not bound a native process being descheduled between
publication and starting its clock. Documentation now states that limitation.
The startup-delay regression verifies exclusion of initialization time, not
identical native phase boundaries. Before making an exact mixed-cycle or
like-for-like performance claim, establish sufficient synchronization evidence
and pass the native visual, interaction, and cadence checks. Current results
remain ineligible for toolkit selection and battery acceptance remains
unverified, which is appropriate while native GUI execution is blocked.

Validation: inspected the changed implementations and regression assertions,
plus the updated collector report recording 34 passing Python tests (18
collector, 12 fixture, 4 verification). Did not repeat the broad suite or run
benchmarks. No new blocking regression was found in this scoped review. Only
this review document was written.

## Final integration-only follow-up

Reviewed the subsequent `backend_unavailable_reason` alias and validation-only
report classification changes, plus their regression assertions. **No new
findings.** The alias accepts Godot's explicit reason for a null backend while
still rejecting an unexplained null backend. Configured validation purpose is
forwarded into reporting; explicit non-graphical, headless, offscreen, and minimal
runtime evidence marks the JSON and Markdown as validation only. The Markdown
prominently states that retained metrics/deltas are noncomparable pipeline
diagnostics. A Software backend on a native platform does not itself trigger
headless classification, and `desktop_comparison` remains false in all cases.

The new regression covers each runtime marker, configured purpose, preservation
of diagnostic metrics, prominent warning text, and native Software classification.
The existing telemetry test now covers the Godot backend-reason alias. Relied on
the updated collector report's 35 passing tests; did not rerun broad tests or
claim the in-progress final smoke result. The earlier synchronization and native
acceptance limitations remain unchanged.
