# Shared fixtures implementation report

Implemented `shared/CONTRACT.md`, `rig.json`, `atlas.png`, `golden.json`,
`preview.png`, `tools/fixtures.py`, and `tests/test_fixtures.py`.

The frozen version 1 contract supplies 12 ordered textured parts, deterministic
distance-driven gait, scripted head/eye tracking, bounded fixed-step tail spring,
64-pixel root excursion, and explicit completed-interval mixed-phase boundaries.
Suspension preserves the entire pose, counters and spring state. The reference
uses the Python standard library; atlas/preview regeneration uses Pillow.

Validation: wrote tests first and observed missing `tools.fixtures` import failure.
After implementation, `rtk proxy python3 -m unittest discover -s tests -p
test_fixtures.py -v` passed all 10 tests. Coverage includes static/hidden freezes,
40/45/55/60-second boundaries, no suspended-time replay, first-step spring numeric
value, root extrema, presentation-independent walking poses, invalid inputs,
rig hierarchy/bounds/finiteness, checked-in golden agreement and tail bounds.
`rtk proxy .venv/bin/python tools/fixtures.py` regenerated the artwork and fixtures.
Inspected `shared/preview.png`: all three poses show a coherent purple cat, complete
parts, alpha edges and no clipping. Engine screenshot comparisons remain for
integration.

A full concurrent suite invocation passed these fixture tests and six collector
tests, but four collector tests failed because `bench.run` and `bench.report` were
not yet implemented by their owner: `test_cli_rejects_invalid_config_before_creating_output`,
`test_cli_saves_bracketed_baselines_summary_and_engine_arguments`,
`test_deltas_exclude_invalid_runs_and_preserve_negative_difference`, and
`test_no_power_does_not_pass_battery`. The coordinator should rerun the full suite
after the independent collector implementation finishes.

No commits: this workspace has no Git repository and initialization was blocked.

## Review correction: complete input silhouette

Expanded the fixed input polygon to include animated ears, paws and tail while
retaining transparent margins. Clarified that vertices are absolute surface
coordinates including `rig.origin`; walk-fixed adds root offset once, while
desktop/mixed scenarios leave the polygon unchanged inside their moving window.
The atlas, preview, motion equations and golden transforms did not change.

Added an alpha-pixel containment regression using all nonzero-alpha atlas pixels
transformed through the full hierarchy at every golden pose and 75 additional
sampled active poses across a 720-tick cycle. It reproduced the old polygon's
static rear-paw exclusion at y=183.5 before the change and passes afterward.
Also reject invalid/nonfinite/out-of-surface/nonconvex polygons and unexpected
part names during fixture validation. The new validator regression failed before
implementation. Final targeted verification: `rtk proxy .venv/bin/python -m
unittest discover -s tests -p test_fixtures.py -v` passed all 12 tests in 2.5 seconds.
Pillow is required for the new artwork-based regression. Full cross-task tests
remain with the coordinator while other agents modify their owned implementations.
