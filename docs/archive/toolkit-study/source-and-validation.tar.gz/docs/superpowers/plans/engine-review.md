# Independent engine and integration review

Reviewed 2026-10-08 against the approved comparison design, implementation plan,
shared/CONTRACT.md, and both engine implementation reports. Read all engine source,
build/configuration scripts, tools/verify.py, CLI tests, and root README. This is a
fresh source review of the new workspace; no Git operations or implementation
edits were made. Collector implementation is covered by its separate reviewer.

## Must-fix finding

**P1 — Godot lifecycle and phase deadlines use simulation time instead of wall time.**
`godot/main.gd:58-61` creates the phase Timer and `godot/main.gd:244-250`
creates the duration/warmup timers without `ignore_time_scale`. Godot clamps
engine simulation delta following a long frame, so these timers permanently
lose part of elapsed wall time. The motion evaluator uses Time.get_ticks_usec,
which means phase scheduling and motion subsequently disagree. A stall during
mixed-rest can delay restarting application processing beyond the 40-second
wall boundary; warmup can reset the measurement epoch late; duration can overrun
while returning success.

Focused reproduction against the installed editor and current source: launch
headless static with duration 1, wait for its ready marker, wait 0.1 seconds,
SIGSTOP only that child for 0.6 seconds, then SIGCONT. The process exited zero
with `{ "elapsed_seconds": 1.462791, "duration": 1.0,
"pose_evaluations": 0 }`. The suspension ends before the requested deadline,
so this is retained timer drift, not an unavoidable late callback during the
suspension. No broad test suites were rerun.

Use real elapsed-time timers for **both** timer construction paths and verify
against the monotonic deadline contract. Godot documents
[`Timer.ignore_time_scale`](https://docs.godotengine.org/en/stable/classes/class_timer.html#class-timer-property-ignore-time-scale)
as updating with real elapsed time; this is the natural minimal correction.
An isolated temporary project copy with `ignore_time_scale = true` added to
both timer construction paths changed the same reproduction to elapsed 0.974836
seconds (exit zero). This establishes that the setting removes retained stall
drift, but also exposes a small early firing from consuming the startup frame's
elapsed time. Guard duration/warmup callbacks against their monotonic target and
rearm for the remaining duration when early. The phase callback already resolves
the current wall phase and rearms toward its next wall boundary. Keep the static
application process disabled. Add focused regressions for retained stall drift,
early lifecycle firing, and phase/warmup deadlines. Temporary reproduction copies
were removed automatically; repository engine files were not edited.

## Review disposition

No other must-fix finding was established in the reviewed scope. The frozen
fixture equations and transform hierarchy agree. Both input adapters consume
absolute hit-polygon coordinates, adding root_offset exactly once only for
walk-fixed; render roots add rig.origin once. Qt counts active dropped intervals
across suspended boundaries and caps catch-up at four; Godot also caps catch-up
but depends on the deadline correction above for wall-time phase scheduling.
Both publish atomic PID readiness markers before lifetime clocks begin, treat
duration as including warmup, reset the motion state after warmup, and label
engine frame callbacks without claiming physical presentation. Pose verification
rejects missing fields, nonfinite numbers, type mismatches, and numeric errors.

Existing evidence is accepted at its stated scope: Qt CTest 2/2 and 44 golden
poses, and Godot release/headless 44-pose and lifecycle checks. This review does
not turn those into desktop acceptance. Qt native window creation failed with
no screens and both Godot native backends aborted before initialization.
Transparency, native focus/input, actual desktop cadence, and native framebuffer
appearance remain unverified. Offscreen/headless configurations are clearly
labeled validation-only and do not qualify for toolkit or battery conclusions.
