# Qt Task 3 implementation report

Implemented the approved Task 3 in `qt/` and `tools/build_qt.py`. Executable:
`build/qt/pet_qt`, Qt 6.10.3, CMake Release, AppleClang 21, arm64 macOS.

## Evidence

- Initial golden CTest failed with `FAIL motion evaluator not implemented` before
  implementing the equations. Final CTest is 2/2: golden poses and CLI lifecycle.
- Independent `tools/verify.py --actual qt/evidence/qt-poses.json` passes all shared
  golden entries within 0.0001. Tests additionally cover phase boundaries, first
  walking step at tick 2701, static freezing, hidden/resume without replay, and
  invalid ticks/scenarios.
- Six process-level CLI tests pass, covering malformed finite/duration/scenario/
  asset arguments, static stopped scheduler, hidden stopped drawing/scheduler,
  active warmup reset, headless dump, and atomic readiness marker with matching PID.
  The readiness test failed on unsupported `--ready-file` before implementation.
- Full current Python suite passed 25/25 when run during this task.
- `qt/evidence/qt-offscreen-smoke.png` was rendered with Qt's **offscreen Software**
  backend and visually inspected. It shows the correct articulated purple fixture
  on a 256×256 transparent image. Its JSON records the actual Software backend,
  scale 1, readback size 256×256, zero pose evaluations/scheduler callbacks and one
  frameSwapped event. This is renderer/lifecycle validation, not a Metal benchmark.
- `qt/evidence/qt-mixed-rest.json` comes from a real 40.2-second offscreen run:
  elapsed 40.201895 seconds, 12 pose evaluations, 13 scheduler callbacks, zero
  overruns/dropped steps. Static lasts until 40 seconds and active stepping resumes
  without replaying that interval.
- Native launch failed before usable window creation: pasteboard/HIServices
  connection errors followed by `Cannot create window: no screens available`,
  SIGABRT / exit 134. No native GUI resource comparison or Metal result is claimed.

## Runtime design

Retained `QSGTransformNode` / `QSGImageNode` hierarchy shares one uploaded
premultiplied atlas texture. Creation, matrix mutation and destruction use Qt's
render-thread lifecycle. GUI pose data transfers during `updatePaintNode`, while
the GUI thread is blocked by scene-graph synchronization. Render callback counters
and intervals use a mutex and survive window teardown safely.

The active scheduler uses precise one-shot deadlines with fixed 60 Hz completed
intervals, at most four catch-up steps and explicit dropped-step/overrun counters.
Static and hidden have no application motion polling; mixed-rest uses one phase
deadline. Warmup resets the motion state, timeline and measurement counters.
`--duration` includes warmup. `--ready-file` writes `{ready:true,pid:...}` atomically
after setup and immediately before the lifetime/phase clocks start.

The requested window is transparent, fixed 256×256, frameless, topmost and
nonfocusing. A data-driven input polygon follows walk-fixed root movement. Desktop
walk placement clamps to available screen bounds; clamps and actual position
writes are counted. Left drag moves the pet and right click quits. Hidden trials
exit at their one-shot deadline. No tray/restore UI is included in this benchmark
prototype.

Telemetry writes once, atomically. It labels `afterRendering`, `afterFrameEnd`,
and `frameSwapped` separately; none is called displayed frames. `displayed_frames`
is null with an explanation. Backend is observed on scene-graph initialization;
hidden runs may have no initialized backend and explicitly report null. During
timed runs, actual framebuffer size is null and derived size is separately labeled
as window dimensions times effective DPR. Untimed screenshots report measured
readback dimensions.

## Limits and rulings

- Native focus preservation, actual pointer pass-through, native transparency,
  hide/restore interaction, display cadence and Metal backend remain unverified
  because native GUI launch failed. `functional_equivalence_verified` is false.
- Used public APIs and clearly labeled derived framebuffer dimensions instead of
  adding Qt's unavailable `GuiPrivate` target. Readback is deliberately restricted
  to untimed screenshot runs. This avoids adding readback workload to benchmarks;
  the tradeoff is no measured timed-run physical framebuffer field.
- Source files remain in the shared new workspace as directed; no git operations
  or system packages were used.

## Reproduction

```sh
rtk proxy python3 tools/build_qt.py --qt-prefix .deps/qt/6.10.3/macos
rtk proxy build/qt/pet_qt --scenario static --duration 1 --assets "$PWD/shared" --output /tmp/qt.json --dump-poses /tmp/qt-poses.json
rtk proxy .venv/bin/python tools/verify.py --actual /tmp/qt-poses.json
rtk proxy env QT_QPA_PLATFORM=offscreen QT_QUICK_BACKEND=software build/qt/pet_qt --scenario static --duration 1 --assets "$PWD/shared" --output /tmp/qt-offscreen.json --screenshot /tmp/qt-offscreen.png
```

API references: [Qt Quick scene graph lifecycle](https://doc.qt.io/qt-6/qtquick-visualcanvas-scenegraph.html),
[QQuickWindow signals](https://doc.qt.io/qt-6/qquickwindow.html),
[QSGImageNode](https://doc.qt.io/qt-6/qsgimagenode.html).
