# Collector implementation report

Implemented `bench/run.py`, `bench/metrics.py`, `bench/report.py`, `bench/README.md` and eleven collector tests in `tests/test_bench.py`.

The version-1 configuration and engine argv contract are documented in `bench/README.md`. Runs use sequential candidates, seeded balanced pair order, bracketing no-pet baselines, saved stdout/stderr, manifest, raw samples, engine summary and JSON/Markdown resource reports. The collector passes `--warmup` and total `--duration` explicitly. Short smoke durations are supported; incomplete mixed cycles are identified in the manifest. Existing output directories are rejected to avoid mixing results.

Process CPU is normalized to one core = 100%; no division by host core count. Successful root-process measurements survive unavailable descendant enumeration as explicitly incomplete `root_only` diagnostics. Tree RSS, WindowServer, footprint, wakeups and power are null with reasons when unavailable. Crashes, early exits, timeouts and invalid/missing engine summaries invalidate candidate runs. Timeout cleanup terminates the owned process group, including descendants that ignore SIGTERM. Resource-only reports always leave battery acceptance unverified and select no toolkit winner.

Validation on 2026-10-08: `rtk proxy .venv/bin/python -m unittest discover -s tests -v` passed all 25 tests (11 collector, 10 fixture, 4 integration verification). Tests were introduced before their implementations and observed failing. Real subprocess coverage includes clean early exit, exit code 7, timeout, stubborn descendant cleanup, CPU sampling after warmup, baseline labeling, null power, correct argument forwarding through a path containing spaces, balanced order and saved output artifacts. Synthetic block tests verify negative paired differences, exclusion of invalid runs and withheld confidence intervals below six blocks.

A real sleeping Python child confirmed that the sandbox permits known-PID CPU/RSS but denies process-tree and WindowServer enumeration with `PermissionError`; the run stayed process-valid with incomplete telemetry and explicit null tree metrics. Engine release-app smoke remains for coordinator integration when binaries are ready. Three paired screening repetitions cannot establish battery or energy acceptance. Bootstrap intervals use paired blocks, never per-second samples, and require at least six available blocks.

Limitations: descendants shorter than the sampling interval can be missed, and newly observed descendant CPU is counted from its first sample. Root-only resource differences are provisional diagnostics, not complete application/compositor measurements. No permission escalation, global settings changes, system package installation, Git commands or user-app termination were performed.

## Review fixes

Addressed collector findings 1, 2, 3, 5 and 6 from `support-review.md`; fixture finding 4 is outside collector ownership. New regressions first reproduced near-end early-exit acceptance, leaked descendants after clean/nonzero root exits, partial-tree reporting and missing telemetry validation.

- Exit detection now uses a dedicated blocking wait thread, independent of sample deadlines. Coverage divides observed intervals by the requested duration; unsampled tails remain missing. Root coverage below 90% invalidates a run.
- Engines receive `--ready-file`. The collector waits for an atomic matching-PID marker with a bounded startup timeout (default 30 seconds), then starts warmup from readiness observation. It records the requested 5ms polling interval and actual last-absent-to-observed latency bracket. Startup delays of 10ms and 250ms do not consume measurement time in real-child regression tests. Missing readiness times out and cleans the child.
- Every root completion path cleans its owned process group. Observable lingering descendants invalidate the run, including when the root returned zero. Tests cover early success, nonzero exit and a timeout descendant ignoring SIGTERM.
- Report means and paired deltas enforce the 90% threshold independently per metric, retain exclusion reasons, and expose coverage/counts. A partial tree cannot silently become a complete observation while root-only diagnostics remain usable.
- Required engine telemetry now includes durations, inferred warmup/measurement boundaries, metadata, counters and event semantics. Requested durations must match within 1 microsecond and actual durations within a documented 50ms timer allowance. Missing fields, false reset flags, duration mismatch, negative counters and nested nonfinite numbers invalidate a run. A real CLI test confirms NaN engine output records invalid results without aborting later candidates.

Latest full verification: `rtk proxy .venv/bin/python -m unittest discover -s tests -v` passed **34 tests** (18 collector, 12 fixture, 4 verification) on 2026-10-08.

Synchronization is explicitly approximate: a ready marker is published immediately before the native clock starts, so publication-to-clock scheduling and polling introduce uncertainty. The actual observation bracket is saved; it is not a shared exact native monotonic origin. `exact_phase_alignment` remains false and manifests label whole mixed cycles as requested, not proven complete aligned cycles. Dedicated exit waiting also retains OS/thread scheduling latency; it does not claim kernel exit timestamps. Resource screening remains provisional, and battery acceptance unverified.

## Validation-only report labeling

Integration follow-up: JSON now classifies explicit validation configurations and headless/offscreen/minimal engine runtimes as `purpose: validation_only`, with reasons and `desktop_comparison: false`. Markdown opens with **VALIDATION ONLY — headless/offscreen, not a desktop performance comparison** when headless/offscreen evidence exists. Raw metrics and deltas remain visible as noncomparable pipeline diagnostics. A software backend alone does not trigger headless classification, and native screening never assumes equivalence passed.

Accepted Godot's explicit `backend_unavailable_reason` alias without weakening the missing-reason rejection. Verified the actual `results/integration/validation-smoke/runs/0002-static-godot-metal/engine-summary.json` through the stricter validator successfully. Focused regressions first failed for the missing classification and backend alias, then passed. Latest full suite: **35 tests passed** (19 collector, 12 fixture, 4 verification).
