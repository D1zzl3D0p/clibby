# Scoped engine re-review

Reviewed 2026-10-08. Scope: the timing correction for the must-fix finding in
engine-review.md, its new CLI regressions and updated implementation report,
and the new tools/configure.py scenario selection / validation naming changes.
No implementation edits or broad test reruns were performed.

**Disposition: original finding resolved; no new must-fix finding established.**

Both Godot timer construction paths now use real elapsed time through
ignore_time_scale. Duration and warmup timers share start_usec as their origin;
deadline_reached compares Time.get_ticks_usec against an absolute deadline and
rearms early callbacks. This addresses both retained suspension drift and the
early-expiry behavior observed in the first review. Phase callbacks resolve the
current monotonic wall phase and rearm for the next phase boundary. The warmup
epoch is the scheduled start plus warmup duration, so delayed delivery no longer
moves the measurement timeline. Static/hidden retain stopped application
processing; no recurring application polling was added.

The two process-level regressions exercise a real 0.6-second SIGSTOP/SIGCONT
interval. They require the one-second deadline not to fire early or retain the
suspension drift, require zero static application callbacks, and verify the
measurement timeline remains elapsed minus scheduled warmup when suspension
crosses that boundary. The author's updated evidence reports all eight CLI tests
passing in the editor and both rebuilt release exports, and 44 golden poses
passing. Accepted that focused evidence without repeating the same suites.

The configure helper restricts --scenarios to recognized app scenarios and
preserves the default matrix when omitted. Validation mode gives each candidate
an explicit validation name, keeps headless/offscreen arguments and labels, and
records pipeline validation as its purpose. These changes introduce no desktop
performance claim.

Native transparency, focus/input behavior, display cadence, and native visual
equivalence remain unverified. This re-review does not expand the headless test
evidence into graphical or battery acceptance.
