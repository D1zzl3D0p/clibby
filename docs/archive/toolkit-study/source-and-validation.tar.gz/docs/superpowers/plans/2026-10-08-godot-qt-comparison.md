# Godot and Qt Comparison Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox syntax for tracking.

**Goal:** Build matched runnable desktop-pet prototypes and a reproducible resource comparison, keeping battery conclusions conditional on valid energy evidence.

**Architecture:** Shared JSON rig/motion fixtures and atlas define one workload; independent Godot and Qt implementations evaluate the same poses. A Python collector launches one candidate at a time, saves raw samples, and reports measured resource differences separately from unverified battery impact.

**Tech Stack:** Godot 4.7.2 release export; Qt 6 C++/CMake Release; Python standard library and psutil for tooling; Pillow for deterministic fixture artwork generation.

**Spec:** `docs/superpowers/specs/2026-10-08-godot-qt-comparison-design.md`

## Global Constraints

- A 256 by 256 logical-pixel transparent surface.
- One 2D character made from a fixed atlas containing 12 authored textured parts.
- Simulated motion advances at a fixed 60 Hz while active.
- Translation tolerance 0.0001 logical pixels, rotation tolerance 0.0001 radians, and scale tolerance 0.0001.
- No frame-by-frame disk logging; write buffered telemetry at exit.
- Static and hidden suspend application motion; remaining engine wakeups count.
- Primary mixed timeline: 45 seconds animated idle, 15 seconds desktop walking per minute.
- Missing metrics are null with a reason, never zero.
- Only equivalent visual/functional/cadence configurations qualify for toolkit selection.
- No battery claim from CPU, memory, Energy Impact, or CPU/GPU component power.
- Work inside this new project. Do not install system packages, close user apps, or change global settings.

## Review Focus

1. Invalid scenario/duration/asset arguments fail clearly; collector never treats a crashed process as efficient idle.
2. Static/hidden phases freeze pose and resume without replaying suspended elapsed time.
3. Mixed phases cross 45/60-second boundaries identically in all implementations.
4. Frame-event counts are labeled according to actual engine semantics, not asserted as displayed frames.
5. Failed/missing power access produces an explicit unverified battery result.

## Execution decisions

The user approved the spec and explicitly requested implementation with extensive subagent use. Proceed after writing this plan without another approval round. This empty workspace has no existing code/branch to isolate. Work in place and initialize a benchmark branch if filesystem permissions permit. Independent engine implementations may run concurrently after their shared contract is fixed; their file ownership must not overlap.

## File ownership

- `shared/`, `tools/fixtures.py`, `tests/test_fixtures.py`: fixture author.
- `godot/`, `tools/build_godot.py`: Godot author.
- `qt/`, `tools/build_qt.py`: Qt author.
- `bench/`, `tests/test_bench.py`: collector author.
- `README.md`, dependency/bootstrap tooling, integration checks, reports: coordinator.

### Task 1: Shared fixtures and reference evaluator

**Files:** `shared/rig.json`, `shared/atlas.png`, `shared/golden.json`, `shared/CONTRACT.md`, `tools/fixtures.py`, `tests/test_fixtures.py`.

**Interfaces:** Freeze `rig.json` version 1 with atlas-relative paths, 12 ordered parts (id, parent, texture rectangle, base position/pivot/size), and motion constants. The evaluator exposes `evaluate_pose(tick: int, scenario: str) -> dict` and `phase_at(seconds: float, scenario: str) -> str`. Pose contains root offset and 12 local transforms x/y/rotation/scale_x/scale_y in pixels/radians. Both engines read the same contract.

- [x] Write and run reference tests before evaluator implementation:

```python
def test_static_is_frozen():
    assert evaluate_pose(0, 'static') == evaluate_pose(600, 'static')

def test_mixed_boundary():
    assert phase_at(44.999, 'mixed-active') == 'idle-motion'
    assert phase_at(45, 'mixed-active') == 'walk-desktop'
    assert phase_at(60, 'mixed-active') == 'idle-motion'
```

- [x] Define deterministic bounded gait/head/tail equations and frame-step rules in CONTRACT.md before engines implement them. Keep integration/equations small enough to port exactly.
- [x] Generate a deliberately simple authored 12-part pet atlas (not generated AI art) and expected poses at boundary ticks; capture a fixture preview.
- [x] Validate part names, parent order, bounds, finite transforms, tick validation and scenario rejection. Run `rtk proxy python3 -m unittest discover -s tests -v`.

### Task 2: Godot prototype

**Files:** `godot/project.godot`, `godot/main.tscn`, `godot/main.gd`, `godot/motion.gd`, `godot/export_presets.cfg`, `tools/build_godot.py`.

**Consumes:** Task 1 contract. CLI after Godot `--`: `--scenario NAME --duration SECONDS --output PATH --assets ABS_SHARED_DIR`; optional `--dump-poses PATH`, `--screenshot PATH` for untimed validation. Engines exit autonomously when duration expires.

**Produces:** Release app, pose dump, telemetry JSON with engine/version/backend/scenario/duration, pose evaluation count, draw-event count, window-position writes, frame-event intervals, framebuffer scale and error status.

- [x] First create a headless golden-pose check that fails before the motion evaluator exists.
- [x] Implement the fixture evaluator in GDScript and validate all golden ticks against tolerance.
- [x] Render atlas parts via Sprite2D hierarchy. Use transparent unfocused overlay, conservative hit polygon, small window and screen-bounded movement.
- [x] Select Dummy audio/physics, disable keep-awake, halt pose callbacks in static/hidden, and use explicit low-processor settings. Preserve restore/quit input. Use a one-shot duration timer.
- [x] Validate CLI errors and that static counts do not rise. Export matching release templates locally. Build/test both Mobile+Metal and Compatibility where available.

### Task 3: Qt Quick prototype

**Files:** `qt/CMakeLists.txt`, `qt/main.cpp`, `qt/motion.h`, `qt/motion.cpp`, `qt/petitem.h`, `qt/petitem.cpp`, `qt/tests.cpp`, `tools/build_qt.py`.

**Consumes/produces:** Same fixture/CLI/telemetry contract as Task 2, with accurately named Qt submission/presentation-queue event counters.

- [x] Add a CTest golden-pose executable before evaluator implementation; verify missing evaluator failure.
- [x] Implement C++ equations, then run golden/boundary/invalid-scenario tests.
- [x] Create retained QSG transform/image nodes in a QQuickItem/QQuickWindow; update graphics only on the render thread.
- [x] Use Metal where supported, explicit transparency/no-focus/input mask, and a stopped scheduler in static/hidden phases. Use a one-shot duration timer.
- [ ] Validate CLI errors, actual backing size/backend, clean auto-exit, static counters, and untimed screenshots.

### Task 4: Resource collector and report

**Files:** `bench/__init__.py`, `bench/run.py`, `bench/metrics.py`, `bench/report.py`, `tests/test_bench.py`.

**Interfaces:** `python3 -m bench.run --config PATH --output DIR --warmup 30 --duration 120 --repeats 3`. Config records candidate argument arrays, renderer labels, asset path and scenarios. Use argv arrays without a shell. Launch each app with duration = warmup + measurement plus bounded exit margin. Collect monotonic samples, process CPU-time deltas, RSS, descendant processes and optional WindowServer metrics using psutil. Save engine summary and process exit status alongside samples.

- [x] Write tests using a real short-lived Python subprocess, covering early exit, nonzero exit, timeout cleanup, one-core CPU normalization, baseline labeling and null unavailable metrics.
- [x] Implement balanced/randomized paired order with saved seed, baseline before/after each pair, manifest and raw JSON samples. Record uncontrolled environmental conditions rather than asserting battery control.
- [x] Report per-run CPU/RSS/engine cadence, paired deltas, valid run counts and confidence intervals only when enough independent blocks exist. Resource-only results always say battery acceptance unverified.

```python
def test_no_power_does_not_pass_battery():
    report = summarize_runs(resource_only_runs)
    assert report['battery_acceptance'] == 'unverified'

def test_early_exit_is_invalid():
    result = collect_process([sys.executable, '-c', 'pass'], duration=2)
    assert not result['valid']
```

- [x] Run all Python tests and smoke collector against both release applications.

### Task 5: Integration, comparison and documentation

**Files:** `README.md`, `tools/bootstrap.py`, `tools/verify.py`, `bench/config.local.json` (ignored local paths), `docs/results/2026-10-08-comparison.md`.

- [x] Obtain pinned official dependencies in `.deps/`, retain source URLs/version/checksums, and keep caches under the workspace. If unavailable, report exact missing component without substituting an editor for a release benchmark.
- [x] Verify reference + both engine golden dumps agree; run all test suites and release builds.
- [ ] Compare screenshots/overlay behavior outside timing runs. Record unverified desktop interaction tests explicitly.
- [ ] Run short smoke tests first, then the resource screening matrix only for usable graphical runtimes. No parallel benchmark candidates.
- [ ] Use authorized power telemetry if accessible. Otherwise finish resource analysis and provide the reproducible long battery protocol with battery status unverified.
- [x] Have a fresh reviewer inspect shared contracts, both implementations and collector validity; fix major findings and run affected tests.
- [x] Document actual measurements with raw-data paths, tested host and limitations. No toolkit winner from invalid or functionally inequivalent runs.

## Final execution status

Tasks 1–4 are implemented and reviewed. All available automated checks pass:
35 Python tests, 2 Qt CTest targets, 8 CLI tests per Godot release, and 44 matching
poses across all three builds. The validation-only collector completed 6/6 runs.

Unchecked steps above are partially blocked: Qt offscreen screenshot and derived
backing scale were checked, but native backend/framebuffer and overlay behavior
could not be verified. Both native candidates failed before readiness, so no
native resource matrix was run. Power tooling is unavailable here; the report
contains reproduction and battery-protocol guidance, not an energy conclusion.
Hidden benchmark scenarios auto-exit; a separate interactive restore UI remains
outside this prototype. Windows/Linux desktop behavior remains untested.

See `implementation-progress.md` and `docs/results/2026-10-08-comparison.md` for
final evidence paths, review fixes and environment limits.

## Completion evidence

Deliver runnable prototypes, source and build/run instructions; matching fixture tests; reproducible collector; an honest report of actual measurements or specific environment blockers. Long controlled battery sessions remain unverified unless they are actually performed with adequate evidence.
