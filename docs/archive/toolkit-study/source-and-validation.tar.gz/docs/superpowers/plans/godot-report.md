# Godot prototype implementation evidence

Task 2 source and both official release exports are implemented. Native graphical
validation is blocked in this execution environment: both release executables
abort with SIGABRT (return code -6) before application initialization, without
stdout/stderr or readiness. No graphical or power measurement is claimed.

## Artifacts

- `godot/project.godot`, `main.tscn`, `main.gd`, `motion.gd`, `export_presets.cfg`.
- `tools/build_godot.py`: local official template, self-contained editor caches.
- `build/godot/BetterPets-mobile.app/Contents/MacOS/Better Pets Godot`.
- `build/godot/BetterPets-compatibility.app/Contents/MacOS/Better Pets Godot`.
- `results/godot/poses-mobile.json`, `poses-compatibility.json`.
- `results/godot/release-verification.json`: both 44 poses, maximum error zero.
- `results/godot/gui-launches.json`: graphical command lines, return codes,
  stdout/stderr and readiness results.
- `results/godot/export-mobile.log`, `export-compatibility.log`: export evidence.

All paths above are relative to `/Users/dizzler/Projects/Repos/better-pets`.

## Build and test

From the repository root:

```sh
rtk proxy python3 tools/build_godot.py --renderer all
rtk proxy .deps/godot/Godot.app/Contents/MacOS/Godot --headless --path godot --script test_motion.gd
rtk proxy python3 godot/test_cli.py
rtk proxy env 'PET_GODOT_BINARY=/Users/dizzler/Projects/Repos/better-pets/build/godot/BetterPets-mobile.app/Contents/MacOS/Better Pets Godot' python3 godot/test_cli.py
rtk proxy env 'PET_GODOT_BINARY=/Users/dizzler/Projects/Repos/better-pets/build/godot/BetterPets-compatibility.app/Contents/MacOS/Better Pets Godot' python3 godot/test_cli.py
```

Observed: both release builds exit zero; golden evaluator passes all 44 entries;
eight CLI tests pass in editor, Mobile release, and Compatibility release. Tests
cover static/hidden suspension, invalid scenario/numbers/assets, ready handshake,
warmup reset, autonomous exit and process-suspension deadlines. Repository-wide `python3 -m unittest discover
-s tests -v` also passed 25 tests at this integration point. Initial missing
evaluator check failed with exit 1, before implementation. Runtime tests initially
failed due to absent main implementation; malformed asset test first failed its
expected validation message before schema validation was added.

Example untimed release pose dump:

```sh
rtk proxy 'build/godot/BetterPets-mobile.app/Contents/MacOS/Better Pets Godot' --headless -- --scenario static --duration 1 --output "$PWD/results/godot/unused.json" --assets "$PWD/shared" --dump-poses "$PWD/results/godot/poses-mobile.json"
```

Native runs use the same command without `--headless`/`--dump-poses`. Add
`--warmup 30`, `--duration 150`, `--ready-file ABS_PATH` as required by the
collector. `--screenshot ABS_PNG_PATH` is an untimed native visual check.

## Runtime details and limitations

Motion uses GDScript scalar doubles, exact shared equations, bounded four-step
catchup, counted dropped steps and wall-phase boundaries. Warmup reconstructs the
initial state and resets measurement counters. Static/hidden stop application
`_process`; only phase, warmup and exit deadline timers remain. Hidden disables
the rendering loop. Residual engine wakeups are intentionally left measurable.
Audio and 2D/3D physics are Dummy, keep-screen-on is false, and low-processor mode
uses 10,000 microseconds with a 60 FPS active cap.

Telemetry calls the drawing signal `engine_frame_post_draw_events`, explicitly
not physical presentation. Backend and framebuffer metrics are null with reasons
in explicit headless validation. The source uses the actual RenderingServer
driver for native telemetry, 256 logical pixels with screen-scale backing size,
an unfocusable transparent always-on-top window, shared input polygon and
screen-clamped desktop movement. These graphical paths, screenshot output, live
cadence, focus, pass-through and Retina sizing could not be validated because of
the preinitialization abort. Native close-request exits through buffered
telemetry. A separate restore control for deliberately hidden mode is not yet
provided; rerunning a visible scenario restores visibility.

Godot's standard preinitialization user-data setup tries creating
`~/Library/Application Support/BetterPetsComparison`; the sandbox denies it.
This is nonfatal for headless tests. Automatic desktop file logging and shader
caching are disabled; the app writes only explicitly supplied output paths.
Godot's system certificate lookup also logs a sandbox error. The editor's
`_sc_` marker keeps editor caches under `.deps/godot/editor_data`; export uses
explicit local custom-template paths. No global package installation or engine
fork was made. Both artifacts reuse the same official release native binary;
their packed project renderer feature differs.

Ruling: accept documented nonfatal preinitialization sandbox errors rather than
changing HOME, writing system directories or modifying official engine binaries.
Ruling: headless tests establish functional math and lifecycle behavior only;
they do not qualify either native configuration for toolkit selection.

Relevant official documentation:
[data paths](https://docs.godotengine.org/en/latest/tutorials/io/data_paths.html),
[project settings and desktop log override](https://docs.godotengine.org/en/stable/classes/class_projectsettings.html).

## Review fix: deadlines survive process suspension

The new real SIGSTOP/SIGCONT regression first reproduced a one-second static run
taking 1.490939 seconds after a 0.6-second process suspension. Godot's ordinary
Timer uses a process delta reduced by the physics catchup limit. Both the phase
timer and one-shot timers now set `ignore_time_scale=true`, which uses the engine
step captured before that reduction. Unscaled timers alone could fire early
(observed 0.982539 seconds), so one-shot callbacks also compare the monotonic
clock against their absolute deadlines and rearm for any remaining time.

Warmup sets its epoch to `start_usec + warmup`, preserving the intended measurement
origin when process suspension delays delivery of the warmup callback. A second
regression suspends through the warmup boundary and verifies the measurement
duration equals total elapsed minus warmup. Static still records zero application
motion callbacks. Eight CLI tests passed with the editor and both rebuilt release
bundles; the 44-pose editor golden test also passed.

The broader suite was rerun during review with the wrong interpreter: system Python ran 34 tests and reported
`test_hit_polygon_contains_transformed_alpha_across_motion_extrema` missing PIL,
and `test_startup_delay_does_not_consume_warmup_or_measurement` reporting incomplete
root CPU/RSS samples. The coordinator confirmed system Python lacks both Pillow
and psutil. Full-suite validation must use `.venv/bin/python`; the coordinator is
running that integration check after all review fixes. Godot's eight CLI tests
use only the Python standard library and passed with system Python; they do not
require Pillow or psutil.
