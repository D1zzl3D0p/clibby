# Desktop pet: Godot and Qt Quick comparison

Status: proposed architecture for review; no implementations or performance measurements yet.

## Intent and decision

Build a small, expressive desktop companion with consistent artwork and procedural behavior across platforms. It should eventually understand surfaces and interact with objects. Background battery impact is a first-class constraint.

Implement two disposable but representative prototypes before choosing the production toolkit:

- Godot, using its 2D scene graph and GDScript.
- Qt Quick, using a C++ procedural controller and retained GPU scene graph.

Compare the complete usable applications, including their desktop-window integration. A smaller installer or lower process CPU reading alone does not establish better battery life. Neither implementation is presumed to win.

The proposed acceptance target is less than 5% battery-runtime loss during a declared representative workload on a reference laptop. This is a requirement to validate, not an existing result. Continuous animation must also have its own reported result; resting periods cannot conceal the cost of perpetual motion.

## Scope and local evidence

The first comparison targets the available Apple M4 Pro MacBook Pro: 12 CPU cores, 16 GPU cores, 24 GB memory, arm64, macOS 27.2. Repeat the selected tests on Windows before making a cross-platform efficiency claim. Linux support must name the display server/compositor and supported desktop capabilities.

Local inspection on 2026-10-08 found:

- The project directory is empty and is not yet a Git repository.
- CMake and clang++ are available. Godot and Qt tools were not found on PATH or in the inspected application/Homebrew locations.
- `powermetrics` is available. Its help documents estimated CPU/GPU power, task activity, wakeups, and battery samplers. This does not establish access to those samplers.
- `xcrun xctrace list templates` failed because the sandbox prevents creation of its Instruments cache under the user's Library. No Instruments template availability has been established.
- Power-source reporting showed AC power while the battery also reported discharging. This is not a controlled battery-test condition.

These findings permit architecture work, not claims about either toolkit's measured performance. Dependencies will be installed in an allowed project/local dependency location where practical. System-wide installs or profiler permission changes are not assumed.

Out of scope: AI inference, screenshot interpretation, accessibility-based window discovery, networking, accounts, multiple pets, production packaging/updating, 3D art, and a general pet editor. Include only a small diagnostic interface outside timed runs.

## Shared architecture

Both applications implement the same boundaries within one process:

1. **Scenario controller:** reads a workload manifest, uses a monotonic clock, and schedules phase changes.
2. **World snapshot:** logical screen bounds, one floor, pointer target, and optional scripted toy target. It contains data, not OS handles.
3. **Behavior:** chooses a scripted intent during benchmarks; later production behavior can choose the same intents independently.
4. **Motion and pose:** turns intent, elapsed time, and rig parameters into root position and local part transforms. Springs and movement have explicit settle conditions.
5. **Renderer:** maps transforms to retained textured geometry. It does not decide behavior or query desktop state.
6. **Desktop adapter:** handles overlay placement, display scale, input region, focus policy, and visibility. It reports capabilities and failures explicitly.
7. **Telemetry:** retains counters and samples in memory during a run and writes results at phase boundaries/end. No frame-by-frame disk logging.

Share data and contracts first, rather than creating a cross-language runtime library before it is justified. Godot and Qt have independent, small implementations of the same equations. That intentionally measures the practical stacks, including GDScript versus C++ overhead. If a material difference appears, an optional identical pose-trace replay can isolate rendering from procedural calculation.

Future objects expose a target position, surface geometry, and allowed interactions through the world snapshot. A toy drawn by our application can use that contract before real application windows are supported.

## Matched visual and behavior contract

- One 2D character made from a fixed atlas containing 12 authored textured parts, with the same hierarchy, pivots, dimensions, alpha, and ordering in both apps.
- A 256 by 256 logical-pixel transparent surface, with artwork sized to remain inside that surface for every pose. Record actual physical framebuffer size and display scale.
- Both implementations use the same texture resolution, linear filtering, premultiplied-alpha convention, sRGB appearance, and no blur, particles, shadows, HDR, or MSAA. Correct native texture conversion is allowed; verify resulting edges visually.
- Motion includes a gait driven by distance traveled, eye/head tracking of a scripted target, and a bounded damped tail spring. No physics engine is needed for this fixture.
- Simulated motion advances at a fixed 60 Hz while active. Both use the same integration order, constants, initial state, and interpolation rule. Cap catch-up to four steps; record overruns and invalidate pacing comparisons with repeated overruns.
- The acceptance fixtures provide expected poses at specific simulation ticks: translation tolerance 0.0001 logical pixels, rotation tolerance 0.0001 radians, and scale tolerance 0.0001. Test alpha/texture appearance separately from numerical pose matching.
- No randomness in the benchmark. Later random behavior uses a recorded seed.
- Target 60 displayed updates per second during active scenarios. Measure achieved cadence; a requested rate is not evidence of delivery. A secondary 30 FPS configuration is allowed only when applied to both implementations and reported separately.
- Static means no breathing, blinking, spring integration, polling for pointer position, or changing shader parameters. Animated idle is a separate scenario.
- Hidden mode stops application animation and behavior work except a one-shot phase-end event. Any residual engine wakeups remain part of the result.
- On resume, preserve the current pose and reset the simulation time origin; do not replay time spent suspended. A settling transition follows the same deterministic rule in both applications.
- Interaction areas cover the same conservative pet silhouette. Empty window areas pass mouse input through. Moving or clicking the pet must not unexpectedly take focus from another app.

Use screenshot inspection and pose fixtures before timing. A prototype that looks worse, misses frames, captures unintended clicks, or suppresses required behavior does not qualify as the efficient winner.

## Godot implementation

Use a pinned stable Godot release and exported arm64 release application, with editors/debuggers closed during measurement. Import assets before warmup. Record the version, export configuration, and renderer in every result.

- A Node2D hierarchy with Sprite2D parts represents the rig. A single controller advances simulation and applies changed transforms.
- Use the transparent, borderless, always-on-top window configuration and no-focus behavior where supported. The adapter owns window placement and mouse-passthrough regions.
- Select the Dummy audio driver and Dummy 2D and 3D physics backends, disable application physics callbacks, and disable keep-screen-on. Omitting audio nodes or disabling callbacks alone does not shut down those servers. Any residual engine housekeeping still belongs in the result.
- In active phases, use a documented frame cap and vsync configuration, checking actual frame delivery.
- In static and hidden phases, stop animation callbacks and enable low-processor mode with an explicit sleep interval. Verify pointer/drag responsiveness before accepting an interval. Log the interval as part of the configuration.
- Do not claim that low-processor mode makes the engine event-driven. It skips unnecessary drawing but still sleeps between loop iterations. Disabling rendering alone does not stop logic processing.

Compare two supported renderer configurations initially: Mobile with native Metal, and Compatibility with its supported OpenGL path. Confirm transparent overlays actually work in each configuration; report unsupported configurations rather than silently changing visual behavior. Select the better valid configuration on a calibration run, then use fresh runs for the comparison with Qt. Preserve results from both to avoid hiding backend sensitivity.

No custom engine fork or stripped custom build in the initial comparison. Such work would be a separate measured optimization, not an undisclosed advantage.

## Qt Quick implementation

Use a pinned stable Qt 6 release with C++/CMake Release settings and an arm64 application. Use Qt Core, Gui, Qml, and Quick; avoid a webview or Python runtime. Record dependency versions and build settings.

- A QQuickWindow owns the transparent surface. A custom QQuickItem exposes the pet scene.
- Retained QSG transform and textured geometry nodes represent the same parts. Create and update render-thread-owned scene graph resources through the documented synchronization lifecycle.
- A C++ pose controller computes the same fixture motion. Synchronize pose data to the renderer; do not access GUI objects from the render thread.
- Use the native Metal RHI backend on this Mac and record the actual selected backend.
- Avoid Canvas, QQuickPaintedItem, and continuous full-image CPU rasterization; these would measure a different rendering approach.
- One active scheduler requests pose updates at the target cadence. Stop it entirely when motion settles; static/hidden phases keep only the next scenario deadline. Use elapsed time rather than assuming timer callbacks arrive on time.
- Verify frame limiting on the actual display. Initially use a confirmed 60 Hz display mode if available; otherwise use a limited update scheduler on the current mode and report achieved cadence. Do not change the user's display settings silently.
- Use window flags/masks through the desktop adapter and minimal native macOS handling only when required to satisfy focus and click-through acceptance.

Qt rendering callbacks distinguish request, submission, and presentation. In particular, frameSwapped is not proof that a frame was physically displayed. Report only the timestamps the instrumentation actually observes.

## Workload matrix

All scenarios use a predeclared deterministic path. Run one candidate at a time. Visible scenarios are visible but unfocused, with the same other application focused. Hidden is a distinct state; record observed App Nap behavior where telemetry permits.

| ID | Workload | What it isolates |
|---|---|---|
| baseline | No pet process; identical foreground workload and collector | System/collector noise and baseline power |
| static | Visible character, no pose changes | Runtime, overlay, and wakeup floor |
| idle-motion | Continuous small breathing/head/tail motion, fixed window | Cost of making idle look continuously alive |
| walk-fixed | Full gait and scripted root motion inside a fixed surface | Procedural calculation and rendering |
| walk-desktop | Same gait, root motion applied to desktop-window position | Added window-manager/compositor cost |
| hidden | Process remains alive, window hidden, schedules suspended | Background floor and lifecycle correctness |
| mixed-active | Repeating 60-second cycle: 45 animated idle, 15 walk-desktop | Primary battery gate: a continuously animated companion |
| mixed-rest | Repeating 60-second cycle: 40 static, 15 walk-desktop, 5 animated idle | Secondary battery-saving behavior option |

For walk-fixed and walk-desktop, use a 64-logical-pixel horizontal oscillation so both can replay the same root trajectory without clipping. Keep window and framebuffer dimensions identical. In walk-fixed the root offset is inside the window; in walk-desktop the window carries that offset. Movement/focus/input tests are separate from unattended timing runs.

The mixed workloads are explicit initial product assumptions, not proof of typical user behavior. Battery conclusions must name the workload. Mixed-active is the primary gate; passing mixed-rest alone does not pass it. Report uninterrupted idle-motion and walk-desktop as separate costs. Future changes to the intended duty cycle require rerunning acceptance.

## Measurement protocol

### Calibration and equivalence

1. Build both release apps. Run pose equivalence, transparency, click-through, no-focus, hide/show, and visual checks.
2. Verify the real graphics backend, display mode/scale, drawing surface size, and observed frame cadence.
3. Calibrate Godot renderer/sleep settings and Qt scheduler settings. Freeze both configurations before confirmatory measurements.
4. Measure collector overhead against an otherwise identical baseline. Keep collector settings the same for every candidate.

### Short resource comparison

Start with 30 seconds of warmup and 120 seconds of measurement per phase, three paired repetitions. Randomize candidate order in each repetition and record the order. Place no-pet baselines around each pair; allow thermals to recover before the next run. The mixed scenario starts at its phase-zero state at the start of measurement; run complete cycles. Extend settling in static/hidden trials until observed activity stabilizes, and record that duration.

Record CPU time deltas normalized so 100% means one fully occupied logical core, resident memory and physical footprint when available, CPU wakeups when available, render/submission cadence, missed deadlines, and errors. Record WindowServer activity separately because work can move out of the pet process. Explicitly record unavailable metrics as unavailable.

This stage is a screening test. It can find runaway CPU, renderer differences, obvious idle overhead, and pacing failures. It cannot establish a small battery-runtime difference by itself.

### Energy confirmation

For configurations that pass functional checks, use repeated 15–30 minute paired mixed-active and continuously animated runs with no-pet controls to characterize component-power estimates. Battery-discharge validation uses separate battery-only sessions starting with 60-minute intervals and increases duration/repetitions if pilot variability requires it; this duration is not a guarantee of resolving a 5% effect. Spread confirmatory paired runs across at least two sessions. Keep power source, display brightness/refresh rate, foreground workload, radios, peripherals, and battery state-of-charge range comparable. Record thermal state and interruptions; exclude contaminated runs using criteria set before inspecting the outcome.

Use a fixed local foreground document with a recorded reading/scrolling timeline for the reference workload. Use the same script with and without each pet, offline and without user interaction during measurement. A separate quiet-desktop diagnostic may be included, but it cannot substitute for the declared foreground-workload result.

Battery trials require external power to be disconnected and consistent battery-only telemetry throughout. Record source transitions and invalidate a trial with a transition or contradictory source telemetry. AC-powered trials remain useful for resource and component-power diagnostics, but cannot establish battery-discharge acceptance.

Use locally available authorized macOS tools for CPU/GPU power estimates and task wakeups. Do not assume current Instruments Power Profiler supports Mac merely because it supports iPhone/iPad. Enumerate available Mac templates when access permits.

Estimated CPU/GPU rail power is diagnostic and is not total-system power. Activity Monitor Energy Impact is a relative score, not watts. Battery-runtime estimates require validated whole-system battery energy/discharge measurements under comparable conditions. If unavailable, report resource/SoC estimates and leave the battery target unverified. Do not extrapolate a few percentage points of battery-level change into precise watt measurements.

Run profilers and high-frequency frame tracing separately from the primary energy measurements if their overhead is material. Actual displayed-frame smoothness needs a suitable presentation trace or independent visual verification; application callback timing alone is insufficient.

Do not close user applications, disconnect peripherals, change display settings, or alter global power settings automatically. A noisy normal-desktop run may be useful exploratory evidence but must be labeled uncontrolled.

## Results, significance, and decision

Store a manifest for each run: commit/build identifier, toolkit/version, backend, configuration, hardware/OS, display/scale, power-source state, workload/seed, order, collector settings, warmup, measurement duration, and validity flags. Store raw samples separately from per-run summaries. Missing or unsupported metrics are null with a reason, never zero.

Treat repeated paired blocks as the independent samples, not each one-second observation. Start with the three resource pairs; use at least six valid balanced-order blocks across two sessions for confirmatory energy decisions, increasing duration/repeats when noise prevents a useful interval. Report paired differences and 95% confidence intervals by resampling whole paired blocks, preserving their baseline observations. Do not clamp negative estimates of baseline-subtracted added power to zero; preserve them and their uncertainty. Six blocks may still be insufficient for a narrow interval. Report all valid runs rather than selecting the lowest observed run.

Proposed practical significance rules, declared before measurement:

- Set a practical whole-system power difference margin of max(0.1 W, 1% of baseline system power), using the pooled baseline for the declared workload. A toolkit has a materially better energy result only when the entire paired 95% confidence interval for its power reduction is above that margin. If the instrument cannot resolve that margin, or whole-system watts are unavailable, do not claim this energy win. These thresholds are project choices, not published toolkit specifications.
- The product battery target passes only when the upper confidence bound on modeled runtime loss is below 5% for mixed-active with the declared foreground workload. It fails when the lower bound exceeds 5%; an interval crossing 5% remains unresolved. Apply the same calculation separately to other reported workloads without substituting them for the primary gate.
- CPU, wakeups, and memory are secondary diagnostics. Report absolute differences as well as ratios; a large percentage reduction from a near-zero baseline is not automatically important.
- Both candidates must deliver equivalent visuals, interaction, and frame cadence. Lower power from fewer delivered frames is a quality tradeoff, not a like-for-like win.

For baseline system power P0 and incremental pet power dP, modeled runtime loss is dP / (P0 + dP), assuming equal usable battery capacity and stable workload. Label this a model. A 5% loss budget corresponds to dP < P0 / 19. Never insert CPU/GPU-only power into this total-system formula.

Choose Godot if it passes the battery gate and Qt provides no meaningful measured advantage, because its animation authoring tools are useful. Choose Qt if it passes the battery gate and provides a meaningful validated energy advantage at equivalent quality, or if it passes while Godot fails. If neither passes, revise animation duty cycle/window strategy before adding features. If measurements cannot resolve a difference but both pass, decide using development cost rather than claiming a performance winner. If battery acceptance itself is unavailable or inconclusive, any toolkit choice remains provisional and must be labeled as based on resource evidence and development cost.

## Proposed implementation layout and sequence

The future workspace contains shared fixtures/assets, separate godot and qt applications, benchmark collection/reporting tools, and ignored raw results/dependencies/build products. Keep OS integration within each application's desktop adapter; share its behavioral contract and tests.

Sequence after design review:

1. Pin and obtain dependencies, and establish which telemetry can actually run within the environment.
2. Create the shared rig, motion fixtures, scenario manifest, and result schema.
3. Build Godot and Qt prototypes independently against those frozen contracts.
4. Review equivalence and functional behavior before performance testing.
5. Run resource screening, then perform controlled energy confirmation where available.
6. Write the comparison with raw-data links, uncertainty, limitations, and a toolkit recommendation.

These stages are ready to become an implementation plan. They do not represent completed builds or measurements.

## Primary references

- [Godot renderer overview](https://docs.godotengine.org/en/stable/tutorials/rendering/renderers.html)
- [Godot application performance settings](https://docs.godotengine.org/en/stable/tutorials/ui/creating_applications.html#performance)
- [Godot OS processing controls](https://docs.godotengine.org/en/4.6/classes/class_os.html#class-os-property-low-processor-usage-mode)
- [Godot DisplayServer window capabilities](https://docs.godotengine.org/en/4.5/classes/class_displayserver.html)
- [Qt Quick scene graph and thread lifecycle](https://doc.qt.io/qt-6/qtquick-visualcanvas-scenegraph.html)
- [Qt Quick default renderer](https://doc.qt.io/qt-6/qtquick-visualcanvas-scenegraph-renderer.html)
- [Qt QQuickWindow lifecycle and frame signals](https://doc.qt.io/qt-6/qquickwindow.html)
- [Qt timer accuracy](https://doc.qt.io/qt-6/qchronotimer.html)
- [Qt window positioning and input masks](https://doc.qt.io/qt-6/qwindow.html)
- [Apple: efficient graphics](https://developer.apple.com/library/archive/documentation/Performance/Conceptual/power_efficiency_guidelines_osx/UsingEfficientGraphics.html)
- [Apple: energy monitoring](https://developer.apple.com/library/archive/documentation/Performance/Conceptual/power_efficiency_guidelines_osx/MonitoringEnergyUsage.html)
