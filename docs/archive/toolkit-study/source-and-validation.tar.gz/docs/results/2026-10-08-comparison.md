# Godot / Qt comparison: implementation and validation

## Outcome

Both prototypes are implemented and their release builds are available. The
shared motion contract is validated. The user subsequently ran the native
screening protocol outside the execution sandbox: **24/24 candidate trials
completed successfully**. Qt is the stronger resource-screening candidate for
these builds; functional/rendering equivalence and battery impact remain
unverified. No final toolkit winner is selected.

## Native screening results

Evidence: [generated summary](../../results/native-screening/summary.md),
[manifest](../../results/native-screening/manifest.json), and raw per-run
telemetry under `results/native-screening/runs/`. Each scenario has three paired
repetitions, five seconds warmup and twenty seconds measurement. The native host
is Apple Silicon macOS, using Godot Mobile/Metal and Qt Quick Metal. Qt's hidden
scenario never initializes its scene graph, so its backend is correctly null.

| Scenario | Godot process CPU | Qt process CPU | Godot RSS MiB | Qt RSS MiB |
|---|---:|---:|---:|---:|
| Static | 1.241% | 0.757% | 272.69 | 80.74 |
| Animated idle | 11.096% | 9.062% | 277.06 | 80.80 |
| Desktop walking | 16.079% | 12.309% | 278.95 | 80.90 |
| Starts hidden | 0.843% | 0.004% | 276.59 | 66.24 |

These are arithmetic means of per-run, time-weighted process-tree metrics;
100% CPU means one logical core. RSS is resident memory, not physical footprint.
Qt used about 71% less visible RSS (roughly 196–198 MiB less during animation),
18% less animated-idle application CPU, and 23% less walking application CPU.
The active CPU differences are about 2.0 and 3.8 percentage points of one core,
not corresponding battery-runtime improvements. Qt RSS was lower in every pair;
CPU was lower in every idle, walking and hidden pair, but only two static pairs.

Two independent read-only audits verified the raw metrics and engine telemetry.
Process-tree coverage was 95.276–99.996%; missing terminal samples were excluded,
not counted as zero. All observed trees contained one process. All active runs
advanced simulation near 60 Hz, with zero reported dropped steps or overruns.

The interpretation has several concrete limits:

- **Interaction during timing:** Qt static runs `0001`/`0006` recorded 70/110
  window position writes, and idle run `0022` recorded 43. In the inspected source,
  these stationary-scenario writes originate from dragging. Walking run `0030`
  recorded 583 clipped placement attempts; every other run recorded zero.
- **Rendering cadence differs:** Godot walking reported about 52 draw-completion
  events/second, Qt about 60 presentation-queue events/second. These are different
  instrumentation points and neither proves displayed frame delivery. Godot
  walking interval p95 was about 33 ms; Qt walking about 17.4 ms. Both simulations
  still advanced near 60 Hz.
- **Window work differs:** Godot rounds placement at device-pixel resolution;
  Qt rounds logical coordinates. Starting positions and drag support also differ.
  Both report a 256×256 logical surface at DPR 2, but the timed runs do not contain
  independently measured framebuffer dimensions. Qt's final invisible/unexposed
  flags are sampled after the event loop exits, not proof of an invisible trial.
- **Hidden means starting hidden:** Qt's 66 MiB result does not establish memory
  after a previously visible pet becomes hidden.
- **Energy remains unknown:** WindowServer access was denied; power, wakeups and
  physical footprint were unavailable. Baseline system CPU varied substantially.
  Three short repetitions and an uncontrolled foreground workload cannot support
  a battery-runtime conclusion. All runs remain `comparison_eligible=false`.

The next controlled comparison should align placement/rounding and interaction
behavior, verify native visual equivalence and displayed cadence, then repeat
without touching either pet during timing. Keep Qt as the provisional resource
favorite. A subsequent controlled energy trial is required to decide whether
either implementation meets the under-5% battery-runtime-loss target.

## Initial sandbox validation

The initial execution sandbox could not launch a usable native desktop window. Qt aborted
with `Cannot create window: no screens available`; both Godot native release
configurations abort before application initialization and readiness. A headless
Godot process or Qt Software/offscreen window is a different workload and cannot
stand in for the requested desktop overlay.

## Built artifacts

| Implementation | Local artifact | Validation available |
|---|---|---|
| Godot 4.7.2 Mobile | `build/godot/BetterPets-mobile.app` | Release export, golden poses, lifecycle/CLI tests |
| Godot 4.7.2 Compatibility | `build/godot/BetterPets-compatibility.app` | Release export, golden poses, lifecycle/CLI tests |
| Qt 6.10.3 Release | `build/qt/pet_qt` | CTest, golden poses, lifecycle/CLI tests, offscreen screenshot |

All three match the same 44 expected poses within 0.0001 units. The reference
includes static/hidden freezing, exact mixed-phase boundaries, a bounded tail
spring, and distance-driven gait. The atlas and image filtering are shared.

Final verification passed 35 Python tests, both Qt CTest targets (including six
CLI lifecycle cases), and eight CLI tests for each Godot release configuration.
The final headless/offscreen pipeline completed all six candidate runs across
static, idle-motion and hidden scenarios. These establish software validation;
they do not establish native rendering or energy equivalence.

The authored fixture preview is [here](../../shared/preview.png). The actual Qt
offscreen render is [here](../../qt/evidence/qt-offscreen-smoke.png); it validates
the retained scene renderer, not native transparency or Metal performance.

## What independent review improved

- The hit region now contains transformed nontransparent artwork across sampled
  poses, including ear tips and feet. Its regression failed with the old polygon.
- Godot timers use real elapsed time and monotonic deadline guards. Tests suspend
  and resume the process to catch late deadlines and early timer firing.
- The collector separates engine startup from warmup through a readiness marker.
  Its observation uncertainty is retained; exact shared-clock phase alignment is
  not claimed.
- Early process exit cannot silently count as a fully observed trial. Metric
  coverage uses requested measurement duration, with incomplete metrics excluded
  from averages and paired differences.
- Owned child-process groups are cleaned up even when their root already exited.
- Engine telemetry is checked for finite values, duration, warmup, scenario,
  counters and metadata. Missing capabilities remain null with a reason.

Review records are in [support review](../superpowers/plans/support-review.md),
[support re-review](../superpowers/plans/support-rereview.md), and
[engine review](../superpowers/plans/engine-review.md), and
[engine re-review](../superpowers/plans/engine-rereview.md).

## Available measurement access

The tested host reports Apple M4 Pro (12 CPU cores, 16 GPU cores), 24 GB memory,
arm64 and macOS 27.2. Known process IDs expose CPU time and RSS. Global process
enumeration is sandbox-denied, so descendant and WindowServer totals may remain
unavailable. RSS is not physical footprint.

`powermetrics` reports that it requires superuser access. Instruments CLI cannot
create its cache under the user's Library. No permissions or power settings were
changed. CPU/GPU component estimates, even if available, would not establish
whole-system battery-runtime loss. The proposed under-5% target is unverified.

Raw integration records are under `results/integration/`. Native smoke correctly
records both candidates invalid and selects no winner. Validation-only smoke
checks process launch, readiness, collection, telemetry and report generation;
its resource samples are not desktop performance evidence.

## Run the actual desktop comparison

From a normal Terminal with desktop access, in this project directory:

```sh
rtk proxy .venv/bin/python tools/configure.py --scenarios static idle-motion walk-desktop hidden
rtk proxy .venv/bin/python -m bench.run \
  --config bench/config.local.json --output results/native-screening \
  --warmup 5 --duration 20 --baseline-duration 5 --cooldown 1 --repeats 3
```

This is roughly a 12-minute resource screen, plus startup time. It is a shortened
exploratory run, not the full design's confirmatory protocol. Check native
transparency, focus preservation, input passthrough, scale and frame pacing before
interpreting differences. The same script also works without the `rtk proxy`
prefix on a machine without RTK.

To compare Godot Compatibility, regenerate the config with
`--godot-renderer compatibility`, and use a different output directory. Confirm
the actual backend in engine telemetry rather than assuming the requested driver
was selected. Keep backgrounds/foreground workload unchanged between candidates.

For the primary mixed workload, configure `--scenarios mixed-active`, then use
`--warmup 30 --duration 120 --baseline-duration 120 --repeats 3` for resource
screening. Longer battery-only paired sessions, validated total-system discharge
measurement, controlled conditions, and sufficient independent repetitions are
still required for the battery acceptance decision in the approved design.

If no material energy difference can be resolved and both pass the battery gate,
choose on development ergonomics. If battery evidence remains unavailable, any
toolkit selection is provisional.
