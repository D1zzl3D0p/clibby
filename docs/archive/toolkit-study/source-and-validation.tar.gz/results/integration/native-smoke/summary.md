# Resource screening report

Battery acceptance: **unverified**. No validated whole-system battery energy/discharge measurements; resource usage cannot establish battery-runtime loss.

Valid candidate runs: 0/2. No toolkit winner is selected.

| Candidate | Scenario | Valid / attempted | Tree CPU % | Tree RSS MiB | Root CPU % | Root RSS MiB |
|---|---|---:|---:|---:|---:|---:|
| godot-metal | static | 0 / 1 | unavailable | unavailable | unavailable | unavailable |
| qt-metal | static | 0 / 1 | unavailable | unavailable | unavailable | unavailable |

CPU: 100% is one logical core. Root-only measurements are incomplete process-tree diagnostics.

## Paired differences

Differences are candidate B minus candidate A; negative numbers are preserved.

- static, qt-metal minus godot-metal: 0 valid paired blocks.

## Limitations

- Normal desktop environment is uncontrolled unless separately documented.
- Root-only metrics exclude descendants and are provisional diagnostics.
- RSS sums may double-count shared memory; footprint unavailable.
- Application callbacks do not prove displayed frame delivery.
- Three paired repetitions do not establish confirmatory energy significance.

Engine cadence and exact event labels are retained in summary.json and each engine-summary.json. Raw process samples and baseline observations are in runs/*/samples.json. Power, wakeups and physical footprint remain null with reasons.
