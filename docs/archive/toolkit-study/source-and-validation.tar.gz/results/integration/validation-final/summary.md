# Validation pipeline report

**VALIDATION ONLY — headless/offscreen, not a desktop performance comparison.**

Operationally valid runs only demonstrate that the collection pipeline completed. All metrics and paired differences below are noncomparable validation diagnostics.

Battery acceptance: **unverified**. No validated whole-system battery energy/discharge measurements; resource usage cannot establish battery-runtime loss.

Valid candidate runs: 6/6. No toolkit winner is selected.

| Candidate | Scenario | Valid / attempted | Tree CPU % | Tree RSS MiB | Root CPU % | Root RSS MiB |
|---|---|---:|---:|---:|---:|---:|
| godot-headless-validation | hidden | 1 / 1 | unavailable | unavailable | 0.248 | 81.533 |
| godot-headless-validation | idle-motion | 1 / 1 | unavailable | unavailable | 2.095 | 81.626 |
| godot-headless-validation | static | 1 / 1 | unavailable | unavailable | 0.359 | 81.579 |
| qt-offscreen-validation | hidden | 1 / 1 | unavailable | unavailable | 0.000 | 18.250 |
| qt-offscreen-validation | idle-motion | 1 / 1 | unavailable | unavailable | 1.905 | 20.074 |
| qt-offscreen-validation | static | 1 / 1 | unavailable | unavailable | 0.000 | 19.828 |

CPU: 100% is one logical core. Root-only measurements are incomplete process-tree diagnostics.

## Paired differences

Differences are candidate B minus candidate A; negative numbers are preserved.

- hidden, qt-offscreen-validation minus godot-headless-validation: 1 valid paired blocks.
  - root_cpu_percent: -0.248; 95% interval: at least six independent valid paired blocks required.
  - root_rss_bytes: -66356520.136; 95% interval: at least six independent valid paired blocks required.
  - system_cpu_percent: -129.065; 95% interval: at least six independent valid paired blocks required.
- idle-motion, qt-offscreen-validation minus godot-headless-validation: 1 valid paired blocks.
  - root_cpu_percent: -0.191; 95% interval: at least six independent valid paired blocks required.
  - root_rss_bytes: -64542741.614; 95% interval: at least six independent valid paired blocks required.
  - system_cpu_percent: 10.685; 95% interval: at least six independent valid paired blocks required.
- static, qt-offscreen-validation minus godot-headless-validation: 1 valid paired blocks.
  - root_cpu_percent: -0.359; 95% interval: at least six independent valid paired blocks required.
  - root_rss_bytes: -64751003.043; 95% interval: at least six independent valid paired blocks required.
  - system_cpu_percent: -106.598; 95% interval: at least six independent valid paired blocks required.

## Limitations

- Normal desktop environment is uncontrolled unless separately documented.
- Root-only metrics exclude descendants and are provisional diagnostics.
- RSS sums may double-count shared memory; footprint unavailable.
- Application callbacks do not prove displayed frame delivery.
- Three paired repetitions do not establish confirmatory energy significance.

Engine cadence and exact event labels are retained in summary.json and each engine-summary.json. Raw process samples and baseline observations are in runs/*/samples.json. Power, wakeups and physical footprint remain null with reasons.
