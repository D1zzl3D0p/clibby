#!/usr/bin/env python3
"""Export a local official Godot release template without a global installation."""
import argparse
import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--renderer', choices=['mobile', 'compatibility', 'all'], default='all')
    parser.add_argument('--godot', type=Path, default=ROOT / '.deps/godot/Godot.app/Contents/MacOS/Godot')
    parser.add_argument('--template', type=Path, default=ROOT / '.deps/godot-templates/templates/macos.zip')
    args = parser.parse_args()
    if not args.godot.is_file() or not args.template.is_file():
        parser.error('local Godot executable and macOS export template are required; run tools/bootstrap.py')
    output = ROOT / 'build/godot'
    output.mkdir(parents=True, exist_ok=True)
    logdir = ROOT / 'results/godot'
    logdir.mkdir(parents=True, exist_ok=True)
    # Official editor self-contained mode: all editor caches remain in .deps.
    if args.godot.resolve().is_relative_to(ROOT / '.deps'):
        (args.godot.resolve().parents[3] / '_sc_').touch()
    presets = []
    for i, renderer in enumerate(['mobile', 'compatibility']):
        presets.append(f'''[preset.{i}]
name="macos-{renderer}"
platform="macOS"
runnable=true
advanced_options=false
dedicated_server=false
custom_features="pet_{renderer}"
export_filter="all_resources"
include_filter=""
exclude_filter="test_*"
export_path="../build/godot/BetterPets-{renderer}.app"
script_export_mode=2

[preset.{i}.options]
custom_template/debug={json.dumps(str(args.template.resolve()))}
custom_template/release={json.dumps(str(args.template.resolve()))}
export/distribution_type=0
binary_format/architecture="universal"
application/bundle_identifier="org.betterpets.comparison.{renderer}"
application/short_version="1.0"
application/version="1.0"
application/category="Games"
application/high_res=true
codesign/codesign=0
notarization/notarization=0
''')
    (ROOT / 'godot/export_presets.cfg').write_text('\n'.join(presets))
    for renderer in ['mobile', 'compatibility'] if args.renderer == 'all' else [args.renderer]:
        artifact = output / f'BetterPets-{renderer}.app'
        subprocess.run([str(args.godot.resolve()), '--headless', '--path', str(ROOT / 'godot'),
                        '--log-file', str(logdir / f'export-{renderer}.log'), '--export-release',
                        f'macos-{renderer}', str(artifact)], check=True, cwd=ROOT)
        print(artifact)

if __name__ == '__main__':
    main()
