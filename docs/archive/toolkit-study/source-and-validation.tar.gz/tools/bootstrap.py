#!/usr/bin/env python3
"""Install pinned macOS benchmark tools locally, never into system directories."""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEPS = ROOT / ".deps"
DOWNLOADS = DEPS / "downloads"
GODOT = "4.7.2"
QT = "6.10.3"
RELEASE = f"https://github.com/godotengine/godot-builds/releases/download/{GODOT}-stable"


def run(*args: str) -> None:
    subprocess.run(list(args), cwd=ROOT, check=True)


def download(url: str, destination: Path) -> None:
    if destination.is_file():
        return
    partial = destination.with_suffix(destination.suffix + ".partial")
    run("curl", "--fail", "--location", "--silent", "--show-error",
        "--max-time", "600", "--output", str(partial), url)
    partial.replace(destination)


def verified_godot_archive(local_name: str, upstream_name: str) -> Path:
    sums = DOWNLOADS / "SHA512-SUMS.txt"
    download(f"{RELEASE}/SHA512-SUMS.txt", sums)
    entries = {line.split(maxsplit=1)[1].lstrip(" *"): line.split()[0]
               for line in sums.read_text().splitlines() if line.strip()}
    destination = DOWNLOADS / local_name
    download(f"{RELEASE}/{upstream_name}", destination)
    with destination.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha512").hexdigest()
    if digest != entries.get(upstream_name):
        raise RuntimeError(f"SHA512 mismatch: {destination}; remove it and retry")
    return destination


def install_godot() -> None:
    editor = verified_godot_archive("godot.zip", f"Godot_v{GODOT}-stable_macos.universal.zip")
    executable = DEPS / "godot/Godot.app/Contents/MacOS/Godot"
    if not executable.exists():
        run("unzip", "-q", str(editor), "-d", str(DEPS / "godot"))
    templates = verified_godot_archive("export_templates.tpz", f"Godot_v{GODOT}-stable_export_templates.tpz")
    target = DEPS / "godot-templates/templates"
    target.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(templates) as archive:
        for name in ("macos.zip", "version.txt"):
            (target / name).write_bytes(archive.read(f"templates/{name}"))
    run(str(executable), "--version")


def install_qt() -> None:
    prefix = DEPS / f"qt/{QT}/macos"
    if not all((prefix / f"lib/cmake/{module}/{module}Config.cmake").exists()
               for module in ("Qt6", "Qt6Quick", "Qt6Qml")):
        run("uv", "run", "--cache-dir", str(ROOT / ".cache/uv"),
            "--with", "aqtinstall==3.3.0", "aqt", "install-qt", "mac", "desktop",
            QT, "clang_64", "--outputdir", str(DEPS / "qt"),
            "--archives", "qtbase", "qtdeclarative")
    run(str(prefix / "bin/qtpaths"), "--qt-version")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--only", choices=("godot", "qt"))
    args = parser.parse_args()
    if platform.system() != "Darwin" or platform.machine() != "arm64":
        parser.error("This bootstrap targets Apple Silicon macOS; source applications are portable.")
    DOWNLOADS.mkdir(parents=True, exist_ok=True)
    if args.only in (None, "godot"):
        install_godot()
    if args.only in (None, "qt"):
        install_qt()
    manifest_path = DEPS / "toolchains.json"
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}
    if args.only in (None, "godot"):
        manifest["godot"] = {"version": GODOT, "source": RELEASE, "checksum": "SHA512-SUMS.txt"}
    if args.only in (None, "qt"):
        manifest["qt"] = json.loads((ROOT / "tools/dependencies.json").read_text())["qt"]
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f"bootstrap: {error}", file=sys.stderr)
        raise SystemExit(1)
