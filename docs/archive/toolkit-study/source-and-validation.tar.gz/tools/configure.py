#!/usr/bin/env python3
"""Resolve example commands into a local native or validation-only benchmark config."""
import argparse
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "bench/config.local.json")
    parser.add_argument("--validation-only", action="store_true",
                        help="Use headless/offscreen engines; never a desktop performance result")
    parser.add_argument("--godot-renderer", choices=("mobile", "compatibility"), default="mobile")
    parser.add_argument("--scenarios", nargs="+", choices=("static", "idle-motion", "walk-fixed",
                        "walk-desktop", "hidden", "mixed-active", "mixed-rest"))
    args = parser.parse_args()
    example = ROOT / "bench/config.example.json"
    config = json.loads(example.read_text())
    config["assets"] = str(ROOT / "shared")
    if args.scenarios:
        config["scenarios"] = args.scenarios
    for candidate in config["candidates"]:
        candidate["argv"][0] = str((example.parent / candidate["argv"][0]).resolve())
    godot, qt = config["candidates"]
    if args.godot_renderer == "compatibility":
        godot["name"] = "godot-compatibility"
        godot["argv"] = [str(ROOT / "build/godot/BetterPets-compatibility.app/Contents/MacOS/Better Pets Godot"),
                           "--rendering-method", "gl_compatibility", "--rendering-driver", "opengl3", "--"]
        godot["renderer"] = "Compatibility/OpenGL requested; confirm telemetry"
    if args.validation_only:
        godot["name"] = "godot-headless-validation"
        qt["name"] = "qt-offscreen-validation"
        godot["argv"].insert(1, "--headless")
        godot["renderer"] = "headless; validation only"
        qt["environment"] = {"QT_QPA_PLATFORM": "offscreen", "QT_QUICK_BACKEND": "software"}
        qt["renderer"] = "offscreen software; validation only"
        config["environment"]["purpose"] = "pipeline validation, not desktop resource comparison"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(config, indent=2) + "\n")
    print(args.output)


if __name__ == "__main__":
    main()
