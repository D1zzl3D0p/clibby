extends Node2D

const Motion = preload("res://motion.gd")
var options: Dictionary = {}
var rig: Dictionary
var motion
var sprites: Dictionary = {}
var render_root: Node2D
var start_usec: int
var epoch_usec: int
var last_tick: int = 0
var evaluations: int = 0
var callbacks: int = 0
var draw_events: int = 0
var window_writes: int = 0
var clipped_writes: int = 0
var dropped_steps: int = 0
var overruns: int = 0
var draw_intervals: Array = []
var last_draw_usec: int = 0
var base_position: Vector2i
var screen_rect: Rect2i
var dpr: float = 1.0
var graphical: bool = false
var finished: bool = false
var phase_timer: Timer
var errors: Array = []
var screenshot_done: bool = false
var measuring: bool = false

func _ready() -> void:
	set_process(false)
	if not parse_options():
		get_tree().quit(2)
		return
	var parsed = JSON.parse_string(FileAccess.get_file_as_string(options.assets.path_join("rig.json")))
	if not valid_rig(parsed):
		fail("invalid rig.json")
		return
	rig = parsed
	var image = Image.load_from_file(options.assets.path_join(str(rig.get("atlas", "atlas.png"))))
	if image == null or image.is_empty():
		fail("invalid atlas image")
		return
	if options.has("dump-poses"):
		dump_poses()
		return
	graphical = DisplayServer.get_name() != "headless"
	motion = Motion.new(rig)
	OS.low_processor_usage_mode = true
	OS.low_processor_usage_mode_sleep_usec = 10000
	Engine.max_fps = 60
	DisplayServer.screen_set_keep_on(false)
	get_viewport().transparent_bg = true
	if graphical:
		setup_window(image)
	RenderingServer.frame_post_draw.connect(on_draw)
	phase_timer = Timer.new()
	phase_timer.one_shot = true
	# Timer's unscaled engine step is captured before physics catch-up clamps it.
	# Use it for wall deadlines, including process suspension/resumption.
	phase_timer.ignore_time_scale = true
	phase_timer.timeout.connect(update_phase)
	add_child(phase_timer)
	if options.has("ready-file"):
		var pending_path: String = options["ready-file"] + ".tmp"
		if not write_json(pending_path, {"ready": true, "pid": OS.get_process_id()}) or DirAccess.rename_absolute(pending_path, options["ready-file"]) != OK:
			fail("cannot publish ready file")
			return
	start_usec = Time.get_ticks_usec()
	epoch_usec = start_usec
	measuring = options.warmup == 0.0
	one_shot(options.duration, finish, start_usec)
	if options.warmup > 0.0:
		one_shot(options.warmup, reset_measurement, start_usec)
	update_phase()
	if graphical and options.has("screenshot"):
		one_shot(0.15, save_screenshot)

func parse_options() -> bool:
	var args = OS.get_cmdline_user_args()
	var allowed = ["scenario", "duration", "warmup", "output", "assets", "dump-poses", "screenshot", "ready-file"]
	if args.size() % 2 != 0:
		printerr("arguments must be --name value pairs")
		return false
	for i in range(0, args.size(), 2):
		var key = args[i].trim_prefix("--")
		if not args[i].begins_with("--") or key not in allowed or options.has(key):
			printerr("unknown or duplicate argument: ", args[i])
			return false
		options[key] = args[i + 1]
	for required in ["scenario", "duration", "output", "assets"]:
		if not options.has(required):
			printerr("missing argument: --", required)
			return false
	if options.scenario not in Motion.SCENARIOS:
		printerr("invalid scenario: ", options.scenario)
		return false
	options.warmup = options.get("warmup", "0")
	for key in ["duration", "warmup"]:
		if not str(options[key]).is_valid_float():
			printerr("invalid ", key)
			return false
		options[key] = float(options[key])
		if not is_finite(options[key]):
			printerr("nonfinite ", key)
			return false
	if options.duration <= 0.0 or options.warmup < 0.0 or options.warmup >= options.duration:
		printerr("duration must be positive and exceed nonnegative warmup")
		return false
	if not str(options.assets).is_absolute_path() or not FileAccess.file_exists(options.assets.path_join("rig.json")):
		printerr("assets must be an absolute directory containing rig.json")
		return false
	for key in ["output", "dump-poses", "screenshot", "ready-file"]:
		if options.has(key) and (str(options[key]).is_empty() or not DirAccess.dir_exists_absolute(str(options[key]).get_base_dir())):
			printerr("output parent directory does not exist: ", options[key])
			return false
	return true

func fail(message: String) -> void:
	printerr(message)
	get_tree().quit(2)

func numeric_array(value, length: int) -> bool:
	if not value is Array or value.size() != length:
		return false
	for number in value:
		if not (number is float or number is int) or not is_finite(float(number)):
			return false
	return true

func valid_rig(data) -> bool:
	if not data is Dictionary or data.get("version") != 1 or not data.get("parts") is Array or data.parts.size() != 12:
		return false
	if not numeric_array(data.get("origin"), 2) or not data.get("atlas") is String or not data.get("motion") is Dictionary:
		return false
	if not numeric_array(data.get("atlas_size"), 2) or not data.get("hit_polygon") is Array or data.hit_polygon.size() < 3:
		return false
	for point in data.hit_polygon:
		if not numeric_array(point, 2):
			return false
	for key in ["hz", "max_catchup_steps", "root_amplitude", "root_period_ticks", "stride_distance", "tail_stiffness", "tail_damping", "tail_angle_limit", "tail_velocity_limit"]:
		var number = data.motion.get(key)
		if not (number is float or number is int) or not is_finite(float(number)) or number <= 0:
			return false
	if data.motion.hz != 60 or data.motion.max_catchup_steps != 4:
		return false
	var names: Array = []
	for part in data.parts:
		if not part is Dictionary or not part.get("id") is String or part.id in names or not part.has("parent"):
			return false
		if part.parent != null and part.parent not in names:
			return false
		for field in ["position", "pivot", "size"]:
			if not numeric_array(part.get(field), 2):
				return false
		if not numeric_array(part.get("rect"), 4) or not (part.get("rotation") is float or part.get("rotation") is int) or not is_finite(float(part.rotation)):
			return false
		if part.rect[0] < 0 or part.rect[1] < 0 or part.rect[2] <= 0 or part.rect[3] <= 0 or part.rect[0] + part.rect[2] > data.atlas_size[0] or part.rect[1] + part.rect[3] > data.atlas_size[1]:
			return false
		names.append(part.id)
	return true

func write_json(path: String, data: Dictionary) -> bool:
	var file = FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		printerr("cannot write output: ", path)
		return false
	file.store_string(JSON.stringify(data, "\t", false, true))
	file.close()
	return true

func dump_poses() -> void:
	var golden = JSON.parse_string(FileAccess.get_file_as_string(options.assets.path_join("golden.json")))
	if not golden is Dictionary or not golden.get("poses") is Array:
		fail("invalid golden.json")
		return
	var poses: Array = []
	for entry in golden.poses:
		var pose = Motion.evaluate_pose(rig, int(entry.tick), entry.scenario)
		pose.scenario = entry.scenario
		pose.tick = int(entry.tick)
		poses.append(pose)
	get_tree().quit(0 if write_json(options["dump-poses"], {"version": 1, "poses": poses}) else 2)

func setup_window(image: Image) -> void:
	var window = get_window()
	dpr = DisplayServer.screen_get_scale()
	window.size = Vector2i(roundi(256 * dpr), roundi(256 * dpr))
	window.content_scale_size = Vector2i(256, 256)
	window.content_scale_mode = Window.CONTENT_SCALE_MODE_CANVAS_ITEMS
	window.unresizable = true
	window.borderless = true
	window.always_on_top = true
	window.unfocusable = true
	window.transparent = true
	screen_rect = DisplayServer.screen_get_usable_rect()
	base_position = screen_rect.position + (screen_rect.size - window.size) / 2
	window.position = base_position
	window.close_requested.connect(finish)
	# Cmd-Q remains provided by the native app menu even for an unfocusable pet.
	render_root = Node2D.new()
	render_root.position = Vector2(rig.origin[0], rig.origin[1])
	add_child(render_root)
	var texture = ImageTexture.create_from_image(image)
	for part in rig.parts:
		var sprite = Sprite2D.new()
		sprite.texture = texture
		sprite.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
		sprite.region_enabled = true
		sprite.region_rect = Rect2(part.rect[0], part.rect[1], part.rect[2], part.rect[3])
		sprite.region_filter_clip_enabled = true
		sprite.centered = false
		sprite.offset = -Vector2(part.pivot[0], part.pivot[1])
		if part.parent == null:
			render_root.add_child(sprite)
		else:
			sprites[part.parent].add_child(sprite)
		sprites[part.id] = sprite
	apply_pose()

func apply_pose() -> void:
	if not graphical:
		return
	for part in motion.pose.parts:
		var sprite: Sprite2D = sprites[part.id]
		sprite.position = Vector2(part.x, part.y)
		sprite.rotation = part.rotation
		sprite.scale = Vector2(part.scale_x, part.scale_y)
	var offset = Vector2(motion.pose.root_offset[0], 0.0)
	var fixed = options.scenario == "walk-fixed"
	render_root.position = Vector2(rig.origin[0], rig.origin[1]) + (offset if fixed else Vector2.ZERO)
	if options.scenario in ["walk-desktop", "mixed-active", "mixed-rest"]:
		var desired = base_position + Vector2i(roundi(offset.x * dpr), 0)
		var bounded = Vector2i(clampi(desired.x, screen_rect.position.x, screen_rect.end.x - get_window().size.x), clampi(desired.y, screen_rect.position.y, screen_rect.end.y - get_window().size.y))
		if bounded != desired and measuring:
			clipped_writes += 1
		if get_window().position != bounded:
			get_window().position = bounded
			if measuring:
				window_writes += 1
	var polygon = PackedVector2Array()
	for point in rig.hit_polygon:
		polygon.append((Vector2(point[0], point[1]) + (offset if fixed else Vector2.ZERO)) * dpr)
	DisplayServer.window_set_mouse_passthrough(polygon)

func one_shot(seconds: float, callback: Callable, base_usec: int = -1) -> void:
	var timer = Timer.new()
	timer.one_shot = true
	timer.ignore_time_scale = true
	add_child(timer)
	var deadline = (Time.get_ticks_usec() if base_usec < 0 else base_usec) + ceili(seconds * 1000000.0)
	timer.timeout.connect(deadline_reached.bind(timer, deadline, callback))
	timer.start(seconds)

func deadline_reached(timer: Timer, deadline: int, callback: Callable) -> void:
	if finished:
		timer.queue_free()
		return
	var remaining = deadline - Time.get_ticks_usec()
	if remaining > 0:
		# A newly added Timer may consume the whole creation-frame delta.
		# Guard against early expiry with the same monotonic clock as telemetry.
		timer.start(float(remaining) / 1000000.0)
		return
	callback.call()
	timer.queue_free()

func reset_measurement() -> void:
	motion = Motion.new(rig)
	# A suspended process may deliver this callback after the warmup deadline.
	# Keep the epoch at its declared wall time; missed active steps are counted.
	epoch_usec = start_usec + ceili(options.warmup * 1000000.0)
	last_tick = 0
	evaluations = 0
	callbacks = 0
	draw_events = 0
	window_writes = 0
	clipped_writes = 0
	dropped_steps = 0
	overruns = 0
	draw_intervals.clear()
	last_draw_usec = 0
	measuring = true
	apply_pose()
	update_phase()

func seconds_now() -> float:
	return float(Time.get_ticks_usec() - epoch_usec) / 1000000.0

func update_phase() -> void:
	if finished:
		return
	var seconds = seconds_now()
	if is_processing():
		advance(seconds)
	var phase = Motion.phase_at(seconds, options.scenario)
	var active = phase not in ["static", "hidden"]
	set_process(active)
	if not active:
		last_tick = floori(seconds * 60.0)
	if graphical:
		get_window().visible = phase != "hidden"
		RenderingServer.set_render_loop_enabled(phase != "hidden")
	phase_timer.stop()
	if options.scenario in ["mixed-active", "mixed-rest"]:
		var cycle = fmod(seconds, 60.0)
		var boundary = 60.0
		if options.scenario == "mixed-active" and cycle < 45.0:
			boundary = 45.0
		elif options.scenario == "mixed-rest":
			boundary = 40.0 if cycle < 40.0 else (55.0 if cycle < 55.0 else 60.0)
		# Reset completed suspended intervals without ever replaying them.
		if active and phase == "walk-desktop" and options.scenario == "mixed-rest":
			last_tick = maxi(last_tick, floori((seconds - cycle + 40.0) * 60.0))
		phase_timer.start(maxf(0.001, boundary - cycle))

func _process(_delta: float) -> void:
	if measuring:
		callbacks += 1
	advance(seconds_now())

func advance(seconds: float) -> void:
	var target_tick = floori(seconds * 60.0)
	var pending = target_tick - last_tick
	if pending > 4:
		if measuring:
			dropped_steps += pending - 4
			overruns += 1
		last_tick = target_tick - 4
	var changed = false
	while last_tick < target_tick:
		var updated = motion.step(Motion.phase_at(float(last_tick) / 60.0, options.scenario))
		if updated and measuring:
			evaluations += 1
		changed = changed or updated
		last_tick += 1
	if changed:
		apply_pose()

func on_draw() -> void:
	if not measuring or finished:
		return
	draw_events += 1
	var now = Time.get_ticks_usec()
	if last_draw_usec > 0:
		draw_intervals.append(float(now - last_draw_usec) / 1000000.0)
	last_draw_usec = now

func save_screenshot() -> void:
	if options.scenario == "hidden":
		errors.append("screenshot unavailable while hidden")
		return
	var image = get_viewport().get_texture().get_image()
	if image == null or image.save_png(options.screenshot) != OK:
		errors.append("screenshot save failed")
	else:
		screenshot_done = true

func finish() -> void:
	if finished:
		return
	finished = true
	set_process(false)
	var size = get_window().size
	var result = {"engine": "Godot", "version": Engine.get_version_info().string, "scenario": options.scenario,
		"backend": RenderingServer.get_current_rendering_driver_name() if graphical else null, "rendering_method": RenderingServer.get_current_rendering_method(),
		"backend_unavailable_reason": null if graphical else "headless validation run has no GPU backend",
		"display_driver": DisplayServer.get_name(), "graphical_runtime": graphical, "duration": options.duration,
		"warmup_seconds": options.warmup, "elapsed_seconds": float(Time.get_ticks_usec() - start_usec) / 1000000.0,
		"measurement_seconds": seconds_now(), "pose_evaluations": evaluations, "application_process_callbacks": callbacks,
		"engine_frame_post_draw_events": draw_events, "frame_event_semantics": "RenderingServer.frame_post_draw: engine drawing finished; not physical presentation",
		"frame_event_intervals_seconds": draw_intervals, "window_position_writes": window_writes, "window_clipped_writes": clipped_writes,
		"dropped_steps": dropped_steps, "overruns": overruns, "logical_surface_size": [256, 256],
		"device_pixel_ratio": dpr if graphical else null, "framebuffer_size": [size.x, size.y] if graphical else null,
		"framebuffer_unavailable_reason": null if graphical else "headless validation run", "errors": errors,
		"screenshot_written": screenshot_done, "low_processor_usage_mode": OS.low_processor_usage_mode,
		"low_processor_sleep_usec": OS.low_processor_usage_mode_sleep_usec,
		"audio_driver": AudioServer.get_driver_name(), "physics_2d": ProjectSettings.get_setting("physics/2d/physics_engine"),
		"physics_3d": ProjectSettings.get_setting("physics/3d/physics_engine"), "keep_screen_on": DisplayServer.screen_is_kept_on()}
	get_tree().quit(0 if write_json(options.output, result) and errors.is_empty() else 2)
