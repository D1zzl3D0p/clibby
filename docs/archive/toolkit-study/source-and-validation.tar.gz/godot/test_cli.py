"""Headless runtime contract checks, independent of graphical availability."""
import json
import os
import signal
import subprocess
import tempfile
import time
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ENGINE = Path(os.environ.get('PET_GODOT_BINARY', ROOT / '.deps/godot/Godot.app/Contents/MacOS/Godot'))

class CliTests(unittest.TestCase):
    def run_app(self, extra):
        engine_options = [] if 'PET_GODOT_BINARY' in os.environ else ['--path', str(ROOT / 'godot')]
        return subprocess.run([str(ENGINE), '--headless', *engine_options, '--', *extra], capture_output=True, text=True, timeout=10)

    def test_invalid_scenario(self):
        p = self.run_app(['--scenario', 'invalid', '--duration', '1', '--assets', str(ROOT / 'shared'), '--output', '/tmp/unused.json'])
        self.assertNotEqual(p.returncode, 0)
        self.assertIn('invalid scenario', p.stderr)

    def test_static_suspends_and_exits(self):
        with tempfile.TemporaryDirectory(dir=ROOT / 'results') as tmp:
            path = Path(tmp) / 'result.json'
            p = self.run_app(['--scenario', 'static', '--duration', '0.3', '--assets', str(ROOT / 'shared'), '--output', str(path)])
            self.assertEqual(p.returncode, 0, p.stderr)
            result = json.loads(path.read_text())
            self.assertEqual(result['pose_evaluations'], 0)
            self.assertEqual(result['application_process_callbacks'], 0)
            self.assertGreaterEqual(result['elapsed_seconds'], 0.29)
            self.assertFalse(result['graphical_runtime'])

    def test_hidden_suspends(self):
        with tempfile.TemporaryDirectory(dir=ROOT / 'results') as tmp:
            path = Path(tmp) / 'result.json'
            p = self.run_app(['--scenario', 'hidden', '--duration', '0.3', '--warmup', '0.1', '--assets', str(ROOT / 'shared'), '--output', str(path)])
            self.assertEqual(p.returncode, 0, p.stderr)
            result = json.loads(path.read_text())
            self.assertEqual(result['pose_evaluations'], 0)
            self.assertEqual(result['application_process_callbacks'], 0)

    def test_bad_assets_fail_cleanly(self):
        with tempfile.TemporaryDirectory(dir=ROOT / 'results') as tmp:
            assets = Path(tmp)
            (assets / 'rig.json').write_text(json.dumps({'version': 1, 'parts': [{}] * 12}))
            p = self.run_app(['--scenario', 'static', '--duration', '.1', '--assets', str(assets), '--output', str(assets / 'out.json')])
            self.assertNotEqual(p.returncode, 0)
            self.assertIn('invalid rig.json', p.stderr)

    def test_bad_numbers_fail(self):
        for duration, warmup in [('nan', '0'), ('-1', '0'), ('1', '1'), ('1', '-1')]:
            p = self.run_app(['--scenario', 'static', '--duration', duration, '--warmup', warmup, '--assets', str(ROOT / 'shared'), '--output', str(ROOT / 'results/unused.json')])
            self.assertNotEqual(p.returncode, 0)

    def test_ready_and_warmup_reset(self):
        with tempfile.TemporaryDirectory(dir=ROOT / 'results') as tmp:
            path = Path(tmp) / 'result.json'
            ready = Path(tmp) / 'ready.json'
            p = self.run_app(['--scenario', 'idle-motion', '--duration', '.5', '--warmup', '.2', '--assets', str(ROOT / 'shared'), '--output', str(path), '--ready-file', str(ready)])
            self.assertEqual(p.returncode, 0, p.stderr)
            self.assertTrue(json.loads(ready.read_text())['ready'])
            result = json.loads(path.read_text())
            self.assertLess(result['measurement_seconds'], .4)
            self.assertGreaterEqual(result['pose_evaluations'], 14)
            self.assertLessEqual(result['pose_evaluations'], 20)

    def suspended_run(self, duration='1', warmup='0'):
        with tempfile.TemporaryDirectory(dir=ROOT / 'results') as tmp:
            path = Path(tmp) / 'result.json'
            ready = Path(tmp) / 'ready.json'
            engine_options = [] if 'PET_GODOT_BINARY' in os.environ else ['--path', str(ROOT / 'godot')]
            cmd = [str(ENGINE), '--headless', *engine_options, '--', '--scenario', 'static', '--duration', duration, '--warmup', warmup, '--assets', str(ROOT / 'shared'), '--output', str(path), '--ready-file', str(ready)]
            with subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) as process:
                try:
                    limit = time.monotonic() + 5
                    while not ready.exists() and process.poll() is None and time.monotonic() < limit:
                        time.sleep(.01)
                    self.assertTrue(ready.exists(), 'runtime did not become ready')
                    time.sleep(.1)
                    process.send_signal(signal.SIGSTOP)
                    time.sleep(.6)
                    process.send_signal(signal.SIGCONT)
                    _, stderr = process.communicate(timeout=3)
                    self.assertEqual(process.returncode, 0, stderr)
                finally:
                    if process.poll() is None:
                        process.send_signal(signal.SIGCONT)
                        process.kill()
                        process.wait()
            return json.loads(path.read_text())

    def test_deadline_uses_wall_time_across_process_suspension(self):
        result = self.suspended_run()
        self.assertLess(result['elapsed_seconds'], 1.2, result)
        self.assertGreaterEqual(result['elapsed_seconds'], 1.0, result)
        self.assertEqual(result['application_process_callbacks'], 0)

    def test_warmup_epoch_survives_process_suspension(self):
        result = self.suspended_run(duration='1.2', warmup='.5')
        self.assertGreaterEqual(result['elapsed_seconds'], 1.2, result)
        self.assertLess(result['elapsed_seconds'], 1.4, result)
        self.assertAlmostEqual(result['measurement_seconds'], result['elapsed_seconds'] - .5, delta=.02)
        self.assertEqual(result['application_process_callbacks'], 0)

if __name__ == '__main__':
    unittest.main()
