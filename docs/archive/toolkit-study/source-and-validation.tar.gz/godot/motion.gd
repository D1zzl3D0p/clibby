extends RefCounted

const SCENARIOS = ["static", "idle-motion", "walk-fixed", "walk-desktop", "hidden", "mixed-active", "mixed-rest"]
var rig: Dictionary
var active_ticks: int = 0
var walking_ticks: int = 0
var distance: float = 0.0
var root_x: float = 0.0
var tail: float = 0.0
var velocity: float = 0.0
var pose: Dictionary

func _init(data: Dictionary) -> void:
	rig = data
	pose = base_pose()

static func phase_at(seconds: float, scenario: String) -> String:
	if scenario == "mixed-active":
		return "idle-motion" if fmod(seconds, 60.0) < 45.0 else "walk-desktop"
	if scenario == "mixed-rest":
		var cycle = fmod(seconds, 60.0)
		return "static" if cycle < 40.0 else ("walk-desktop" if cycle < 55.0 else "idle-motion")
	return scenario

static func evaluate_pose(data: Dictionary, tick: int, scenario: String) -> Dictionary:
	assert(tick >= 0 and scenario in SCENARIOS)
	var state = load("res://motion.gd").new(data)
	for j in range(tick):
		state.step(phase_at(float(j) / 60.0, scenario))
	return state.pose

func base_pose() -> Dictionary:
	var parts: Array = []
	for part in rig.parts:
		parts.append({"id": part.id, "x": float(part.position[0]), "y": float(part.position[1]), "rotation": float(part.rotation), "scale_x": 1.0, "scale_y": 1.0})
	return {"root_offset": [root_x, 0.0], "parts": parts}

func step(phase: String) -> bool:
	if phase in ["static", "hidden"]:
		return false
	active_ticks += 1
	var walking = phase in ["walk-fixed", "walk-desktop"]
	var m = rig.motion
	if walking:
		var old_root = root_x
		walking_ticks += 1
		root_x = float(m.root_amplitude) * sin(TAU * walking_ticks / float(m.root_period_ticks))
		distance += abs(root_x - old_root)
	var gait = sin(TAU * distance / float(m.stride_distance)) if walking else 0.0
	var tx = 24.0 * sin(TAU * active_ticks / 180.0)
	var ty = 8.0 * sin(TAU * active_ticks / 240.0)
	var head = 0.5 * atan2(ty, 48.0 + tx)
	var breath = sin(TAU * active_ticks / 180.0)
	var target = 0.25 * sin(TAU * active_ticks / 120.0) + 0.1 * gait
	velocity = clampf(velocity + (float(m.tail_stiffness) * (target - tail) - float(m.tail_damping) * velocity) / 60.0, -float(m.tail_velocity_limit), float(m.tail_velocity_limit))
	tail = clampf(tail + velocity / 60.0, -float(m.tail_angle_limit), float(m.tail_angle_limit))
	if abs(tail) == float(m.tail_angle_limit):
		velocity = 0.0
	pose = base_pose()
	for part in pose.parts:
		match part.id:
			"body":
				part.y -= 1.5 * breath
				part.scale_y = 1.0 + 0.015 * breath
			"head": part.rotation += head
			"tail": part.rotation += tail
			"rear_left", "front_right": part.rotation += 0.35 * gait
			"rear_right", "front_left": part.rotation -= 0.35 * gait
			"eye_left", "eye_right":
				part.x += tx / 24.0 * 1.5
				part.y += ty / 8.0 * 0.75
	return true
