extends SceneTree
var failures: int = 0

func _initialize() -> void:
	if not FileAccess.file_exists("res://motion.gd"):
		printerr("FAIL: motion evaluator does not exist")
		quit(1)
		return
	var evaluator = load("res://motion.gd")
	var root = ProjectSettings.globalize_path("res://../shared")
	var rig = JSON.parse_string(FileAccess.get_file_as_string(root.path_join("rig.json")))
	var golden = JSON.parse_string(FileAccess.get_file_as_string(root.path_join("golden.json")))
	var checked = 0
	for entry in golden.poses:
		var actual = evaluator.evaluate_pose(rig, int(entry.tick), entry.scenario)
		for axis in range(2):
			assert_close(actual.root_offset[axis], entry.root_offset[axis])
		for i in range(entry.parts.size()):
			if actual.parts[i].id != entry.parts[i].id:
				failures += 1
			for key in ["x", "y", "rotation", "scale_x", "scale_y"]:
				assert_close(actual.parts[i][key], entry.parts[i][key])
		checked += 1
	print("PASS" if failures == 0 else "FAIL", ": ", checked, " golden poses; mismatches: ", failures)
	quit(0 if failures == 0 else 1)

func assert_close(actual: float, expected: float) -> void:
	if abs(actual - expected) > 0.0001:
		printerr("FAIL: expected ", expected, " actual ", actual)
		failures += 1
